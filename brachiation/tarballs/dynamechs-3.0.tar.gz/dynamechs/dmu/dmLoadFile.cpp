/*****************************************************************************
 * Copyright 1997, Scott McMillan
 *****************************************************************************
 *     File: dmLoadFile.cpp
 *   Author: Scott McMillan
 *  Created: 30 September 1997
 *  Summary: Miscellaneous config file parsing functions
 *****************************************************************************/

#include <dm.h>
#include <dmLoadFile.h>

//----------------------------------------------------------------------------
//    Summary: scan file until first double quote enclosed string is found,
//             and return this string.
// Parameters: cfg_ptr - ifstream reference to file to be scanned
//             filename - string scanned between double quotes (on return)
//    Returns: TRUE if a double-quote enclosed string is found, else FALSE
//----------------------------------------------------------------------------
bool readFilename(ifstream &cfg_ptr, char *filename)
{
   if (cfg_ptr.getline(filename, FILENAME_SIZE, '\042')) {
      if (cfg_ptr.getline(filename, FILENAME_SIZE, '\042')) {
         if (strlen(filename) > 0) {
            return true;
         }
      }
   }
   return false;
}

//----------------------------------------------------------------------------
//    Summary: scan a file from the current position until a particular string
//             is found.  It will exit (not return) if the EOF is encountered
//             before the search string is found.
// Parameters: cfg_ptr - ifstream reference to file being scanned
//             label - string to be searched for
//    Returns: none
//----------------------------------------------------------------------------
void readConfigParameterLabel(ifstream &cfg_ptr, const char *label)
{
   register int i;
   register unsigned char c = '\0';
   char line[80];

   bool stop = false;

   // Strip off blank lines and comment lines.
   while (!stop && ((i = cfg_ptr.get()) != EOF))
   {
      c = (unsigned char) i;

      if ((c == '\n') || (c == COMMENT_CHAR))
      {
         while ((c != '\n') && ((i = cfg_ptr.get()) != EOF))
         {
            c = (unsigned char) i;
         }
      }
      else
      {
         stop = true;
      }
   }

   if (!stop) {
      cerr << "Error: Parameters file EOF encountered before " << label <<
              " found.\n";
      exit(4);
   }

   cfg_ptr.putback(c);

   // Read in the strings until label is found or EOF encountered.
   while ((cfg_ptr >> line))
   {
      if ((line[0] != COMMENT_CHAR) && (line[0] != '\n'))
      {
         if (strncmp(line, label, strlen(label)) == 0)
         {
            return;
         }
         else
         {
            cerr << "Warning: skipped unrecognized parameter: "
                 << line << endl;
            cerr << "   Wanted: " << label << endl;
         }
      }
      c = '\0';
      while ((c != '\n') && ((i = cfg_ptr.get()) != EOF))
      {
         c =  (unsigned char) i;
      }
   }

   cerr << "Error: Parameters file EOF encountered before " << label
        << " found.\n";
   exit(4);
}
