/*****************************************************************************
 * Copyright 2000, Scott McMillan
 *****************************************************************************
 *     File: glLoadModels.h
 *   Author: Scott McMillan
 *  Created: 
 *  Summary: 
 *****************************************************************************/

#ifndef _GL_LOAD_MODELS_H
#define _GL_LOAD_MODELS_H

#include <dmu.h>
#include <GL/gl.h>

DMU_DLL_API GLuint dmGLLoadFile_scm(char *filename);
DMU_DLL_API GLuint dmGLLoadFile_xan(char *filename);
DMU_DLL_API GLuint dmGLLoadFile_cmb(char *filename);

DMU_DLL_API GLuint glLoadModel(char *filename);

#endif
