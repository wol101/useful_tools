/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmLoadFile.h
 *   Author: Scott McMillan
 *  Created: 27 April 1997
 *  Summary: 
 *****************************************************************************/

#ifndef _DM_LOAD_FILE_H
#define _DM_LOAD_FILE_H

#include <dm.h>
#include <dmu.h>
#include <dmSystem.hpp>

const char COMMENT_CHAR = '#';
const char BLOCK_BEGIN_CHAR = '{';
const char BLOCK_END_CHAR = '}';

enum actuatorTypes {NOMOTOR = 0, DCMOTOR = 1};

// functions from dmLoadFile_dm.cpp
char *getNextToken(ifstream &cfg_ptr,
                   int &line_num,
                   const char *delim = " \n\t\r");
void parseToBlockBegin(ifstream &cfg_ptr, int &line_num);
void parseToBlockEnd(ifstream &cfg_ptr, int &line_num);

dmSystem *dmLoadFile_dm203(ifstream &cfg_ptr);
dmSystem *dmLoadFile_dm21(ifstream &cfg_ptr);
dmSystem *dmLoadFile_dm30(ifstream &cfg_ptr);

#endif
