// ***************************************************************************
// Copyright 1997 Scott McMillan
// ***************************************************************************
//     File: dmUtils.cpp
//   Author: Scott McMillan
//  Project: DynaMechs 2.1
//  Summary: A collection of some useful functions
// ***************************************************************************

#include <dm.h>
#include <dmu.h>
#include <dmObject.hpp>
#include <dmSystem.hpp>
#include <dmArticulation.hpp>
#include <dmLink.hpp>

//----------------------------------------------------------------------------
dmObject *dmuFindObject(const char *label, dmArticulation *system)
{
    const char *name;

    if ((system == NULL) || (label == NULL) || (label[0] == '\0'))
    {
        return NULL;
    }

    // check the System object first
    name = system->getName();
    if (name && strcmp(name, label) == 0)
    {
        return system;
    }

    // finally check the links
    for (unsigned int j=0; j<system->getNumLinks(); j++)
    {
       dmLink *link = system->getLink(j);
       name = link->getName();
       if (name && strcmp(name, label) == 0)
       {
          return link;
       }
    }

    return NULL;
}
