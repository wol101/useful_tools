/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmObject.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: used to name and attach user data to all classes
 *****************************************************************************/

#include <dm.h>
#include <dmObject.hpp>

//============================================================================
// class dmObject
//============================================================================

//----------------------------------------------------------------------------
dmObject::dmObject()
      : m_user_data(NULL),
        m_name(NULL)
{
}

//----------------------------------------------------------------------------
dmObject::~dmObject()
{
   if (m_name)
   {
      free(m_name);
   }

   /* FIXME - without reference counting and not knowing which mechanism
              (malloc or new) was used I cannot dealloc the user data. */
}

//----------------------------------------------------------------------------
void dmObject::setName(const char *name)
{
   // free any previously existing name
   if (m_name)
   {
      free(m_name);
      m_name = NULL;
   }

   // if parameter is non-NULL copy new name
   if (name)
   {
      m_name = (char *) malloc(strlen(name)+1);
      memcpy(m_name, name, strlen(name)+1);
   }
}
