/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegRK4.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: 4th order fixed step size Runge Kutta
 *****************************************************************************/

#ifndef _DM_INTEG_RK4_HPP
#define _DM_INTEG_RK4_HPP

#include <dm.h>
#include <dmIntegrator.hpp>

//============================================================================

/**

This class is under major construction.

This is a concrete integrator class derived from the {\tt dmIntegrator} class,
which implements the fourth order, fixed stepsize Runge-Kutta integration
algorithm.  Note that in the process, four calls to the associated {\tt
dmSystem::ABDynamics} function will be made. The {\tt idt} parameter
corresponds to the size of the step that is taken with a single iteration of
the algorithm.  No judgement of success or failure of the step is made and the
parameter will be unchanged on return.

 */

//======================================================================

class DM_DLL_API dmIntegRK4 : public dmIntegrator
{
public:
   ///
   dmIntegRK4();
   ///
   virtual ~dmIntegRK4();

   ///
   void simulate(Float &delta_t);

private:
   // not implemented
   dmIntegRK4(const dmIntegRK4 &);
   dmIntegRK4 &operator=(const dmIntegRK4 &);

   bool allocateStateVariables();

private:
   // RK4 state and derivative variables
   Float *m_qy,  *m_qdy;
   Float *m_qyt, *m_qdyt;
   Float *m_qdym;
   Float *m_qdyb;
};

#endif
