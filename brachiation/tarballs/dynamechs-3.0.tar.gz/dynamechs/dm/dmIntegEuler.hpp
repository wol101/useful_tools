/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegEuler.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: 1st order fixed step size Euler
 *****************************************************************************/

#ifndef _DM_INTEG_EULER_HPP
#define _DM_INTEG_EULER_HPP

#include <dm.h>
#include <dmIntegrator.hpp>

//============================================================================

/**

This class is under major construction.

This is a concrete integrator class derived from the {\tt dmIntegrator} class,
which implements the first order, fixed stepsize Euler integration algorithm.
The {\tt idt} parameter corresponds to the size of the step that is taken with
a single iteration of the algorithm.  No judgement of success or failure of the
step is made and the parameter will be unchanged on return.

 */

//======================================================================

class DM_DLL_API dmIntegEuler : public dmIntegrator
{
public:
   ///
   dmIntegEuler();
   ///
   virtual ~dmIntegEuler();

   ///
   void simulate(Float &idt);

private:
   // not implemented
   dmIntegEuler(const dmIntegEuler &);
   dmIntegEuler &operator=(const dmIntegEuler &);

   bool allocateStateVariables();

private:
   // RK4 state and derivative variables (also used with Euler)
   Float *m_qy, *m_qdy;
};

#endif
