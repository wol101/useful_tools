/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegrator.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: Base (abtract) numerical integrator class
 *****************************************************************************/

#include <dm.h>
#include <dmIntegrator.hpp>
#include <dmSystem.hpp>

//----------------------------------------------------------------------------
dmIntegrator::dmIntegrator()
      : dmObject(),
        m_system(NULL),
        m_ready_to_sim(false)
{
}

//----------------------------------------------------------------------------
dmIntegrator::~dmIntegrator()
{
}

//----------------------------------------------------------------------------
void dmIntegrator::setSystem(dmSystem *system)
{
   /* FIXME - what if system is NULL?? */
   m_system = system;
   m_ready_to_sim = allocateStateVariables();
}
