/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmActuator.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class declaration for dmActuator.
 *****************************************************************************/

#include <dm.h>
#include <dmObject.hpp>
#include <dmActuator.hpp>

//============================================================================
// class dmActuator
//============================================================================

//----------------------------------------------------------------------------
//    Summary: class constructor
// Parameters: none
//    Returns: none
//----------------------------------------------------------------------------
dmActuator::dmActuator()
      : dmObject(),
        m_stiction_flag(true),
        m_prev_vel(0)
        
{
}


//----------------------------------------------------------------------------
//    Summary: initialize the stiction flag (essentially an internal state var)
// Parameters: qd - initial joint velocity
//    Returns: none
//----------------------------------------------------------------------------
void dmActuator::initStiction(Float qd)
{
   m_prev_vel = qd;
   if (qd == 0.0) 
   {
      m_stiction_flag = true;
   }
   else
   {
      m_stiction_flag = false;
   }
}
