/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmMobileBaseLink.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class implementation for mobile reference members.
 *****************************************************************************/

#include <dm.h>

#include <dmRigidBody.hpp>
#include <dmMobileBaseLink.hpp>
#include <dmEnvironment.hpp>

//======================================================================
// class dmMobileBaseLink: public dmRigidBody, public dmRefMember
//======================================================================

//----------------------------------------------------------------------------
//    Summary: Class constructor for dynamic reference members. 
// Parameters: cfg_file - input file stream reference pointing to appropriate
//                        paramters for this class
//    Returns: none.
//----------------------------------------------------------------------------
dmMobileBaseLink::dmMobileBaseLink() : dmRigidBody()
{
   for (int i = 0; i < 6; i++)
   {
      m_vel[i] = 0.0;
      m_acc[i] = 0.0;
   }
}

//----------------------------------------------------------------------------
dmMobileBaseLink::~dmMobileBaseLink()
{
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::setJointPos(Quaternion q, CartesianVector p)
{
   // normalize the quaternion
   ::normalizeQuat(q);

   m_quat[0]  = q[0];
   m_quat[1]  = q[1];
   m_quat[2]  = q[2];
   m_quat[3]  = q[3];

   m_p[0]   = q[4];
   m_p[1]   = q[5];
   m_p[2]   = q[6];

   ::buildRotMat(m_quat, m_R);
}

//----------------------------------------------------------------------------
//    Summary: set the state of the rigid body (reference member)
//             For EXTERNAL USE ONLY - should not be called in the normal
//             course of simulation because we do not want to reset the contact
//             model, except when the state is being overridden externally.
//
// Parameters: q = [quat_ref pos_ref]
//                  quat_ref - normalized quaternion
//                  pos_ref  - position wrt ICS
//             qd = vel_ref  - spatial velocity wrt ICS
//    Returns: none
//----------------------------------------------------------------------------
void dmMobileBaseLink::setState(Float q[], Float qd[])
{
   setJointPos(&q[0], &q[4]);

   if (qd)
   {
      for (int i=0; i<6; i++)
      {
         m_vel[i]   = qd[i];      // angular velocity and  linear velocity
      }
   }

   /* FIXME - I don't think the following is quite right but it must be done
              with the current contact model when overriding the state. */
   // if (m_contact_model) m_contact_model->reset();

   // Now we must reset the force objects 'cause that is what the contact model
   // has become...
   for (unsigned int i=0; i<m_force.size(); i++)
   {
      m_force[i]->reset();
   }
}

//----------------------------------------------------------------------------
//    Summary: retrieve the state of the reference member
// Parameters: 
//    Returns: q = [quat_ref pos_ref]
//                  quat_ref - normalized quaternion
//                  pos_ref  - position of the body wrt ICS
//             qd = vel_ref  - spatial velocity of bodies wrt ICS
//----------------------------------------------------------------------------
void dmMobileBaseLink::getState(Float q[], Float qd[]) const
{
   q[0] = m_quat[0];
   q[1] = m_quat[1];
   q[2] = m_quat[2];
   q[3] = m_quat[3];

   q[4] = m_p[0];
   q[5] = m_p[1];
   q[6] = m_p[2];

   if (qd)
   {
      for (int i=0; i<6; i++)
      {
         qd[i]  = m_vel[i];
      }
   }
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::getPose(RotationMatrix R, CartesianVector p) const
{
   for (unsigned int i=0; i<3; i++)
   {
      for (unsigned int j=0; j<3; j++)
      {
         R[i][j] = m_R[i][j];
      }
      p[i] = m_p[i];
   }
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::stxToInboard(SpatialVector ,
                                    SpatialVector ) const
{
   exit(1);
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::stxFromInboard(SpatialVector ,
                                      SpatialVector ) const
{
   exit(1);
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::rcongtxToInboardSym(CartesianTensor ,
                                           CartesianTensor ) const
{
   exit(1);
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::rcongtxToInboardGen(CartesianTensor ,
                                           CartesianTensor ) const
{
   exit(1);
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::scongtxToInboardIrefl(SpatialTensor ,
                                             SpatialTensor ) const
{
   exit(1);
}

//----------------------------------------------------------------------------
//    Summary: beginning of AB's Forward Kinematics recursion, called by
//             dmSystem::ABDynamics function only, also computes any contact
//             forces and then m_beta (resultant bias force).
// Parameters: ry - new state of body (provided by numerical integrator)
//                  ry[0..3] - normalized quaternion
//                  ry[4..6] - position wrt ICS
//                  ry[7..12]- spatial velocity wrt ICS
//    Returns: ref_val - various kinematic parameters for ref member that will
//                       be passed on to the first links of each attached
//                       articulation. 
//----------------------------------------------------------------------------
void dmMobileBaseLink::ABForwardKinematics(Float q[], // q[7]
                                           Float qd[], // q[6]
                                           dmABForKinStruct *ref_sys_val,
                                           dmABForKinStruct *ref_val)
{
   register int i, j;

   // set new state 
   setJointPos(&q[0], &q[4]);

   for (i=0; i<6; i++)
   {
      m_vel[i] = qd[i];      // angular velocity and  linear velocity
   }
   qd[6] = 0.0;

   // compute position and orientation (for contact code);
   // FIXME - this isn't quite right - don't know how to deal with ref sys
   // forwardKinematics(ref_val);
   for (i = 0; i < 3; i++)
   {
      ref_val->p_ICS[i] = ref_sys_val->p_ICS[i];
      for (j = 0; j < 3; j++)
      {
         ref_val->p_ICS[i] += ref_sys_val->R_ICS[i][j]*m_p[j];
      }
      rtxFromInboard(&ref_sys_val->R_ICS[i][0],
                     &ref_val->R_ICS[i][0]);
   }

   // compute ref_val->v. (velocity wrt ref mem CS). - This needs to be
   // transformed by ref sys values too????
   rtxFromInboard(m_vel,     &ref_val->v[0]);
   rtxFromInboard(&m_vel[3], &ref_val->v[3]);

   // compute bias (velocity-dependent) force.
   computeBeta(ref_val->v, m_beta);

#ifdef HYDRODYNAMICS
   CartesianVector tem1, tem2;

   // compute a_f-a_g.
   dmEnvironment::getEnvironment()->getFluidVel(tem1);
   rtxFromICS(tem1, ref_val->v_f);

   dmEnvironment::getEnvironment()->getFluidAcc(tem1);
   dmEnvironment::getEnvironment()->getGravity(tem2);

   tem1[XC] -= tem2[XC];
   tem1[YC] -= tem2[YC];
   tem1[ZC] -= tem2[ZC];
   rtxFromICS(tem1, ref_val->a_fg);

   SpatialVector beta_H;
   computeHydrodynamicBias(ref_val, beta_H);
   for (i = 0; i < 6; i++)
   {
      m_beta[i] += beta_H[i];
   }
#endif
}

//----------------------------------------------------------------------------
//    Summary: 
// Parameters: I_star_ref - resultant AB inertia of all articulations combined
//                          and transformed to this mem's CS
//             beta_star_ref - resultant AB force exerted on this from
//                          all the outboard members (combined)
//    Returns: 
//----------------------------------------------------------------------------
void dmMobileBaseLink::ABBackwardDynamics(dmABForKinStruct *ref_val,
                                          SpatialVector beta_star_ref,
                                          SpatialTensor I_star_ref,
                                          SpatialVector f_star_inboard,
                                          SpatialTensor N_refl_inboard)
{
   unsigned int i,j,k;

// compute force objects (if any)
   if (m_force.size())
   {
      SpatialVector force;
      for (j=0; j<m_force.size(); j++)
      {
         m_force[j]->computeForce(ref_val, force);
      
         for (i = 0; i < 6; i++)
         {
            m_beta[i] += force[i];
         }
      }
   }

   for (j = 0; j < 6; j++)
   {
      m_beta[j] += m_external_force[j];
   }

// Lower triangular portion of IStar required.
   for (j = 0; j < 6; j++)
   {
      m_beta_star[j] = m_beta[j] + beta_star_ref[j];
      for (k = j; k < 6; k++)
      {
         m_I_star[j][k] = m_I_star[k][j] =
            I_star_ref[j][k] + m_SpInertia[j][k];
      }
   }

   // IS THIS RIGHT?
   // a full spatial joint transmits no force or inertia across "joint"

   for (i=0; i<6; i++)
   {
      f_star_inboard[i] = 0.0;
      for (j=0; j<6; j++)
      {
         N_refl_inboard[i][j] = 0.0;
      }
   }
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::ABBackwardDynamicsN(dmABForKinStruct *ref_val,
                                           SpatialVector f_star_inboard,
                                           SpatialTensor N_refl_inboard)
{
   unsigned int i,j,k;

// compute force objects (if any)
   if (m_force.size())
   {
      SpatialVector force;
      for (j=0; j<m_force.size(); j++)
      {
         m_force[j]->computeForce(ref_val, force);
      
         for (i = 0; i < 6; i++)
         {
            m_beta[i] += force[i];
         }
      }
   }

   for (j = 0; j < 6; j++)
   {
      m_beta[j] += m_external_force[j];
   }

// Lower triangular portion of IStar required - this is a waste...
   for (j = 0; j < 6; j++)
   {
      m_beta_star[j] = m_beta[j];
      for (k = j; k < 6; k++)
      {
         m_I_star[j][k] = m_I_star[k][j] = m_SpInertia[j][k];
      }
   }

   // IS THIS RIGHT?
   // a full spatial joint transmits no force or inertia across "joint"

   for (i=0; i<6; i++)
   {
      f_star_inboard[i] = 0.0;
      for (j=0; j<6; j++)
      {
         N_refl_inboard[i][j] = 0.0;
      }
   }
}

//----------------------------------------------------------------------------
//    Summary: end of second AB Backward Dynamics recursion AND beginning of
//             third AB Forward Accelerations recursion
//    Returns: accel_ref - gravity (and fluid accel) biased acceleration of the
//                          ref mem wrt ref mem's CS
//             rdy - derivative of state vector required by numerical
//                   integrator, where:
//             rdy[0..2] - Euler angle rates,
//             rdy[3..5] - translational velocity wrt ICS
//             rdy[6..11]- spatial acceleration wrt ICS
//----------------------------------------------------------------------------
void dmMobileBaseLink::ABForwardAccelerations(SpatialVector, // a_inboard,
                                              SpatialVector accel_ref,
                                              Float qd[],
                                              Float qdd[])
{
   register int i, j, k;
   register Float tem;

// Perform the root-free cholesky decomposition (IStar = L D L').
   for (k = 0; k < 5; k++)
   {
      for (i = 5; i > k; i--)
      {
         tem = m_I_star[i][k]/m_I_star[k][k];

         for (j = i; j > k; j--)
         {
            m_I_star[i][j] -= m_I_star[j][k]*tem;
         }
         m_I_star[i][k] = tem;
      }
   }

// Calculate the right hand side of the system of equations.
   for (k = 0; k < 6; k++)
   {
      accel_ref[k] = m_beta_star[k];
   }

   for (k = 0; k < 6; k++)
   {
      for (i = k + 1; i < 6; i++)
      {
         accel_ref[i] -= m_I_star[i][k]*accel_ref[k];
      }
   }

   for (k = 0; k < 6; k++)
   {
      accel_ref[k] = accel_ref[k]/m_I_star[k][k];
   }

   for (k = 5; k > -1; k--)
   {
      for (i = k - 1; i > -1; i--)
      {
         accel_ref[i] -= m_I_star[k][i]*accel_ref[k];
      }
   }

// Compute the unbiased acceleration wrt ICS
   rtxToInboard(&accel_ref[0], &m_acc[0]);
   rtxToInboard(&accel_ref[3], &m_acc[3]);

   CartesianVector tem1;
   dmEnvironment::getEnvironment()->getGravity(tem1);
   m_acc[3] += tem1[XC];
   m_acc[4] += tem1[YC];
   m_acc[5] += tem1[ZC];

// transfer results to derivative of state vector
   // convert vel[0..2] = ^e{omega_r} to Quaternion rates [vxd vyd vzd sd].
   qd[0] = 0.5*( m_vel[0]*m_quat[3]+ m_vel[1]*m_quat[2] - m_vel[2]*m_quat[1]);
   qd[1] = 0.5*(-m_vel[0]*m_quat[2]+ m_vel[1]*m_quat[3] + m_vel[2]*m_quat[0]);
   qd[2] = 0.5*( m_vel[0]*m_quat[1]- m_vel[1]*m_quat[0] + m_vel[2]*m_quat[3]);

   qd[3] =-0.5*(m_vel[0]*m_quat[0] + m_vel[1]*m_quat[1] + m_vel[2]*m_quat[2]);

   for (i=0; i<3; i++)
   {
      qd[i+4]  = m_vel[i+3];

      qdd[i]  = m_acc[i];
      qdd[i+3] = m_acc[i+3];
   }
   qdd[6] = 0.0;
}
