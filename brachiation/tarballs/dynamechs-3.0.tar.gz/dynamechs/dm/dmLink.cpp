/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmLink.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class implementation of Link (abstract base class for all links)
 *****************************************************************************/

#include <dm.h>
#include <dmObject.hpp>
#include <dmLink.hpp>

//============================================================================
// class dmLink
//============================================================================

//----------------------------------------------------------------------------
//    Summary: default class constructor
// Parameters: none
//    Returns: none
//----------------------------------------------------------------------------
dmLink::dmLink()
      : dmObject(),
        m_joint_limit_flag(false),
        m_joint_limit_spring(0.0),
        m_joint_limit_damper(0.0),
        m_joint_friction(0.0)
{
   m_p[0] = m_p[1] = m_p[2] = 0.0;
}

//----------------------------------------------------------------------------
//    Summary: dmLink class destructor
// Parameters: none
//    Returns: none
//----------------------------------------------------------------------------
dmLink::~dmLink()
{
}

//----------------------------------------------------------------------------
//    Summary: perform one step of a forward kinematics recursion to compute
//             the position and orientation of the link in the ICS
// Parameters: link_val_inboard - struct containing the position (p_ICS) and
//                                orientation (R_ICS) of the parent (inboard)
//                                link.
//    Returns: link_val_curr - struct containing the computed position (p_ICS)
//                                and orientation (R_ICS) of this link.
//----------------------------------------------------------------------------
void dmLink::forwardKinematics(dmABForKinStruct *link_val_inboard,
                               dmABForKinStruct *link_val_curr)
{
// Compute R_ICS and p_ICS for this link's coordinate system.
   for (int i = 0; i < 3; i++)
   {
      link_val_curr->p_ICS[i] = link_val_inboard->p_ICS[i];
      for (int j = 0; j < 3; j++)
      {
         link_val_curr->p_ICS[i] += link_val_inboard->R_ICS[i][j]*m_p[j];
      }

      rtxFromInboard(&link_val_inboard->R_ICS[i][0],
                     &link_val_curr->R_ICS[i][0]);
    }
}
