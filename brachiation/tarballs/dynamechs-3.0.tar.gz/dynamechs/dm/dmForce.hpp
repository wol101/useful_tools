/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmForce.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: Abstract base class definition for modelling compliant (functions
 *         : position and velocity) exerted on rigid bodies.
 *****************************************************************************/

#ifndef _DM_FORCE_HPP
#define _DM_FORCE_HPP

#include <dm.h>
#include <dmObject.hpp>

//============================================================================

/** 

This is the abstract base class for all force objects that would be associated
with a {\tt dmRigidBody} class.  This class defines the interface, as all of
its functions are pure virtual ones.  

The {\tt reset} function is one required by the {\tt dmContactModel} because
certain retained state variables when the state of the rigid body is brutally
overridden (which should never be done in a normal simulation).  As such this
requirement on the interface is most unsatisfying.

The {\tt computeForce} function is the heart of this class which computes the
compliant force based on the rigid body's state information provided by the
{\tt dmABForKinStruct} parameter and returns the spatial force in the {\tt
force} parameter.

See also {\tt dmContactModel}, {\tt dmRigidBody}. */

//============================================================================

class DM_DLL_API dmForce : public dmObject
{
public:
   ///
   dmForce();
   ///
   virtual ~dmForce();

   ///
   virtual void reset() = 0;
   ///
   virtual void computeForce(dmABForKinStruct *val, SpatialVector force) = 0;

// rendering functions (for future expansion/visualization):
   ///
   virtual void draw() = 0;

private:
   // not implemented
   dmForce(const dmForce &);
   dmForce &operator=(const dmForce &);
};

#endif
