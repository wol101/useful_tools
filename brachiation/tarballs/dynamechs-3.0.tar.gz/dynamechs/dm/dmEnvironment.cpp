/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmEnvironment.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class implementation of dmEnvironment
 *****************************************************************************/

#include <dm.h>
#include <dmEnvironment.hpp>

// static variable...there can only be one environment
dmEnvironment* dmEnvironment::m_env = NULL;

//============================================================================
// class dmEnvironment : public dmObject
//============================================================================

//----------------------------------------------------------------------------
//    Summary: Constructor for dmEnvironment class loads in all sorts of stuff
// Parameters: cfg_ptr - ifstream containing the necessary parameters to
//                initialize this class
//    Returns: none
//----------------------------------------------------------------------------
dmEnvironment::dmEnvironment()
      : dmObject(),
        x_dim(0),
        y_dim(0),
        grid_resolution(0),
        depth(NULL),
        m_terrain_filename(NULL),
        m_terrain_model_index(-1),
        ground_planar_spring_constant(0.0),
        ground_normal_spring_constant(0.0),
        ground_planar_damper_constant(0.0),
        ground_normal_damper_constant(0.0),
        ground_static_friction_coeff(0.0),
        ground_kinetic_friction_coeff(0.0)
{
   m_gravity[XC] = m_gravity[YC] = m_gravity[ZC] = 0.0;

#ifdef HYDRODYNAMICS
   fluid_density = 0.0;

   for (int i = 0; i < 3; i++)
   {
      fluid_vel[i] = 0.0;
      fluid_acc[i] = 0.0;
   }
#endif
}

//----------------------------------------------------------------------------
dmEnvironment::~dmEnvironment()
{
   if (m_terrain_filename)
   {
      free(m_terrain_filename);
   }
}

// ---------------------------------------------------------------------------
// Function : loadTerrainData
// Purpose  : Function called from constructor to load prismatic terrain data 
// Inputs   : filename containing data
// Outputs  : 
// ---------------------------------------------------------------------------
void dmEnvironment::loadTerrainData(char *filename)
{
   register int i, j;

   //m_terrain_filename = strdup(filename);
   m_terrain_filename = (char *) malloc(strlen(filename)+1);
   memcpy(m_terrain_filename, filename, strlen(filename)+1);

   ifstream data_ptr(filename);
   if (!data_ptr)
   {
      cerr << "Unable to open terrain data file: " << filename << endl;
      exit(3);
   }

   // Read the elevation/depth data in meters.
   data_ptr >> x_dim >> y_dim >> grid_resolution;

#ifdef DEBUG
   cout << "Terrain data: (" << x_dim << ", " << y_dim << ").\n" << flush;
#endif

   // allocate space for and read in depth data;
   depth = new Float *[x_dim];

   for (i = 0; i < x_dim; i++) {
      depth[i] = new Float[y_dim];

      for (j = 0; j < y_dim; j++) {
         data_ptr >> depth[i][j];
      }
   }

   data_ptr.close();
}

// ---------------------------------------------------------------------
// Function : getGroundDepth
// Purpose  : Compute ground location and normal from gridded depth data.
// Inputs   : Current contact position wrt ICS
// Outputs  : Ground depth along z-axis, and normal at this point.
// ---------------------------------------------------------------------
Float dmEnvironment::getGroundDepth(CartesianVector contact_pos,
                                  CartesianVector ground_normal)
{
   register int i;
   Float t, u, depth_var;
   Float norm;
   CartesianVector v1, v2;

   int xindex = (int) (contact_pos[XC]/grid_resolution);
   int yindex = (int) (contact_pos[YC]/grid_resolution);

   if (contact_pos[XC] < 0.0) {
      xindex--;
   }
   if (contact_pos[YC] < 0.0) {
      yindex--;
   }

   t = (contact_pos[XC] -
        ((float) xindex*grid_resolution))/grid_resolution;
   u = (contact_pos[YC] -
        ((float) yindex*grid_resolution))/grid_resolution;

// Walked off the terrain - compute depth equal to closest edge.
   if ((xindex < 0) || (xindex > (x_dim - 2)) ||
       (yindex < 0) || (yindex > (y_dim - 2)))
   {
      // bogus normal.
      //ground_normal[XC] = 0.0;
      //ground_normal[YC] = 0.0;
      //ground_normal[ZC] = -1.0;

      if (yindex < 0) {
         yindex = 0;
         u = 0.0;
      }
      else if (yindex > (y_dim - 2)) {
         yindex = y_dim - 2;
         u = 1.0;
      }

      if (xindex < 0) {
         xindex = 0;
         t = 0.0;
      }
      else if (xindex > (x_dim - 2)) {
         xindex = x_dim - 2;
         t = 1.0;
      }
   }
/*
      if (t > u) {
         depth_var = depth[xindex][yindex] +
            t*(depth[xindex+1][yindex] - depth[xindex][yindex]) +
            u*(depth[xindex+1][yindex+1] - depth[xindex+1][yindex]);
      }
      else {
         depth_var = depth[xindex][yindex] +
            u*(depth[xindex][yindex+1] - depth[xindex][yindex]) +
            t*(depth[xindex+1][yindex+1] - depth[xindex][yindex+1]);
      }

      return (depth_var);
   }
*/

// On the terrain - compute a valid depth and normal.
   if (t > u)                   // upper-left triangle
   {
      // compute depth of terrain at this planar (x,y) coordinate.
      depth_var = depth[xindex][yindex] +
         t*(depth[xindex+1][yindex] - depth[xindex][yindex]) +
         u*(depth[xindex+1][yindex+1] - depth[xindex+1][yindex]);

      // compute normal to face.
      v1[XC] = -grid_resolution;
      v1[YC] = 0.0;
      v1[ZC] = depth[xindex][yindex] - depth[xindex+1][yindex];

      v2[XC] = 0.0;
      v2[YC] = grid_resolution;
      v2[ZC] = depth[xindex+1][yindex+1] - depth[xindex+1][yindex];

      crossproduct(v1, v2, ground_normal);
      norm = sqrt(ground_normal[XC]*ground_normal[XC] +
                  ground_normal[YC]*ground_normal[YC] +
                  ground_normal[ZC]*ground_normal[ZC]);
      for (i = 0; i < 3; i++) {
         ground_normal[i] /= norm;
      }
   }
   else                         // lower-right triangle
   {
      depth_var = depth[xindex][yindex] +
         u*(depth[xindex][yindex+1] - depth[xindex][yindex]) +
         t*(depth[xindex+1][yindex+1] - depth[xindex][yindex+1]);

      // compute normal to face.
      v1[XC] = 0.0;
      v1[YC] = -grid_resolution;
      v1[ZC] = depth[xindex][yindex] - depth[xindex][yindex+1];

      v2[XC] = grid_resolution;
      v2[YC] = 0.0;
      v2[ZC] = depth[xindex+1][yindex+1] - depth[xindex][yindex+1];

      crossproduct(v2, v1, ground_normal);
      norm = sqrt(ground_normal[XC]*ground_normal[XC] +
                  ground_normal[YC]*ground_normal[YC] +
                  ground_normal[ZC]*ground_normal[ZC]);
      for (i = 0; i < 3; i++) {
         ground_normal[i] /= norm;
      }
   }

   return depth_var;
}

// ---------------------------------------------------------------------
// Function : getGroundElevation
// Purpose  : Compute ground location and normal from gridded elevation data.
// Inputs   : Current contact position wrt ICS
// Outputs  : Ground elevation along z-axis, and normal at this point.
// ---------------------------------------------------------------------
Float dmEnvironment::getGroundElevation(CartesianVector contact_pos,
                                        CartesianVector ground_normal)
{
   register int i;
   Float t, u, elevation_var;
   Float norm;
   CartesianVector v1, v2;

   int xindex = (int) (contact_pos[XC]/grid_resolution);
   int yindex = (int) (contact_pos[YC]/grid_resolution);

   if (contact_pos[XC] < 0.0) {
      xindex--;
   }
   if (contact_pos[YC] < 0.0) {
      yindex--;
   }

   t = (contact_pos[XC] -
        ((float) xindex*grid_resolution))/grid_resolution;
   u = (contact_pos[YC] -
        ((float) yindex*grid_resolution))/grid_resolution;

// Walked off the terrain - compute elevation equal to closest edge.
   if ((xindex < 0) || (xindex > (x_dim - 2)) ||
       (yindex < 0) || (yindex > (y_dim - 2)))
   {
      // bogus normal.
      //ground_normal[XC] = 0.0;
      //ground_normal[YC] = 0.0;
      //ground_normal[ZC] = -1.0;

      if (yindex < 0) {
         yindex = 0;
         u = 0.0;
      }
      else if (yindex > (y_dim - 2)) {
         yindex = y_dim - 2;
         u = 1.0;
      }

      if (xindex < 0) {
         xindex = 0;
         t = 0.0;
      }
      else if (xindex > (x_dim - 2)) {
         xindex = x_dim - 2;
         t = 1.0;
      }
   }

// On the terrain - compute a valid elevation and normal.
   if (t > u)                   // upper-left triangle
   {
      // compute elevation of terrain at this planar (x,y) coordinate.
      elevation_var = depth[xindex][yindex] +
         t*(depth[xindex+1][yindex] - depth[xindex][yindex]) +
         u*(depth[xindex+1][yindex+1] - depth[xindex+1][yindex]);

      // compute normal to face.
      v1[XC] = -grid_resolution;
      v1[YC] = 0.0;
      v1[ZC] = depth[xindex][yindex] - depth[xindex+1][yindex];

      v2[XC] = 0.0;
      v2[YC] = grid_resolution;
      v2[ZC] = depth[xindex+1][yindex+1] - depth[xindex+1][yindex];

      crossproduct(v2, v1, ground_normal);
      norm = sqrt(ground_normal[XC]*ground_normal[XC] +
                  ground_normal[YC]*ground_normal[YC] +
                  ground_normal[ZC]*ground_normal[ZC]);
      for (i = 0; i < 3; i++) {
         ground_normal[i] /= norm;
      }
   }
   else                         // lower-right triangle
   {
      elevation_var = depth[xindex][yindex] +
         u*(depth[xindex][yindex+1] - depth[xindex][yindex]) +
         t*(depth[xindex+1][yindex+1] - depth[xindex][yindex+1]);

      // compute normal to face.
      v1[XC] = 0.0;
      v1[YC] = -grid_resolution;
      v1[ZC] = depth[xindex][yindex] - depth[xindex][yindex+1];

      v2[XC] = grid_resolution;
      v2[YC] = 0.0;
      v2[ZC] = depth[xindex+1][yindex+1] - depth[xindex][yindex+1];

      crossproduct(v1, v2, ground_normal);
      norm = sqrt(ground_normal[XC]*ground_normal[XC] +
                  ground_normal[YC]*ground_normal[YC] +
                  ground_normal[ZC]*ground_normal[ZC]);
      for (i = 0; i < 3; i++) {
         ground_normal[i] /= norm;
      }
   }

   return elevation_var;
}


#ifdef HYDRODYNAMICS
// ---------------------------------------------------------------------
// Function : updateFluidMotionEuler
// Purpose  : integrates fluid acceleration to get fluid velocity
// Inputs   : integration stepsize
// Outputs  : 
// ---------------------------------------------------------------------
void dmEnvironment::updateFluidMotionEuler(Float idt, CartesianVector)
{
   register int i;

   for (i = 0; i < 3; i++) {
      fluid_vel[i] += idt*fluid_acc[i];
   }
}
#endif
