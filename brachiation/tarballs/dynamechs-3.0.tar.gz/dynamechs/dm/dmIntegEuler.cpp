/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegEuler.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: 1st order fixed stepsize numerical integrator
 *****************************************************************************/

#include <dm.h>
#include <dmIntegEuler.hpp>

//----------------------------------------------------------------------------
dmIntegEuler::dmIntegEuler()
      : dmIntegrator(),
        m_qy(NULL),
        m_qdy(NULL)
{
}

//----------------------------------------------------------------------------
dmIntegEuler::~dmIntegEuler()
{
   if (m_system)
   {
      // deallocate any state variables.
      if (m_qy)
      {
         delete m_qy;
         delete m_qdy;
      }
   }
}

//----------------------------------------------------------------------------
bool dmIntegEuler::allocateStateVariables()
{
   // delete any preexisting simulation variables
   if (m_qy)   delete m_qy;
   if (m_qdy)  delete m_qdy;

   // allocate new ones
   m_num_state_vars = m_system->makeStateVariable(&m_qy);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy);

   m_system->initSimVars(m_qy, m_qdy);

   if (m_num_state_vars == 0)
   {
      return true;
   }

   if (m_num_state_vars && m_qy && m_qdy)
   {
      return true;
   }

   return false;
}

// ---------------------------------------------------------------------------
// Function : simulateEuler
// Purpose  : Perform dynamic sim and numerical integration to obtain new
//              system state 
// Inputs   : fixed integration stepsize.
// Outputs  : none
// ---------------------------------------------------------------------------
void dmIntegEuler::simulate(Float &delta_t)
{
   register int j;

   // It is left to the user to make sure isReadyToSim returns TRUE
   //if (!m_ready_to_sim) initSimVars();

   // assume m_ry, m_qy state vectors are consistent with internally stored
   // information.

// Step 1. update the state based previously computed information
   for (j = 0; j < m_num_state_vars; j++)
   {
      m_qy[j] += delta_t*m_qdy[j];
   }

// Step 1a. update the derivative based on the new state (and push the new
   // state to the internal variables while I am at it.
   m_system->ABDynamics(m_qy, m_qdy);
}
