/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmForce.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: The base force "widget" class really only defines the interface
 *****************************************************************************/

#include <dm.h>
#include <dmForce.hpp>

//----------------------------------------------------------------------------
dmForce::dmForce() : dmObject()
{
}

//----------------------------------------------------------------------------
dmForce::~dmForce()
{
}
