/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmSystem.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class definitions for dmSystem - top level DynaMechs structure
 *****************************************************************************/

#ifndef _DM_SYSTEM_HPP
#define _DM_SYSTEM_HPP

#include <dm.h>
#include <dmObject.hpp>

//======================================================================

/**

The {\tt dmSystem} is the abstract base class for the top-level in the
DynaMechs object hierarchy.  Subclasses are derived from it which implement the
specifics need for the various types of topologies supported by this library.
Currently only tree topologies are implemented in the {\tt dmArticulation}
subclass, but soon a class implementing a closed chain algorithm will be
added).  This class contains all of the functions (pure virtual and otherwise)
needed to perform the dynamics computation which is only the derivative
computation step of a complete dynamic simulation.  To perform dynamic
simulation, a complete system is put together by assigning links the subclasses
(see the {\tt dmArticulation} class), and is then assigned to one of the {\tt
dmIntegrator} objects.

The function, {\tt makeJointVariable}, is a potentially obsolete holdover from
previous versions of DynaMechs.  That said, this creates a one dimensional
vector of {\tt Floats} that is large enough to hold all of a general joint
variable (one of position, velocity, acceleration, or joint inputs).  The order
in which they are packed into this vector is the same as the order in which
they were added to the subclass.  

A related function, {\tt makeStateVariable}, is now used by the {\tt
dmIntegrator} (and derived) classes to allocate a one-dimensional array that is
large enough to hold the state (position {\em and} velocity) variables for all
of links of all of the articulations.  This is also used to allocate the
derivative of state (velocity and acceleration) variables since they are the
same size.  The {\tt initSimVars} function will initialize the state and
derivative of state vectors with the current state of the system.  The
parameters, {\tt qy} and {\tt qdy}, are the state vectors
that have been allocated with calls to {\tt makeStateVariable}.

{\bf IMPORTANT:} All necessary calls to {\tt makeStateVariable} and {\tt
initSimVars} are done automatically by the {\tt dmIntegrator} class when a {\tt
dmSystem} object is assigned to it.  The {\tt dmIntegrator} class cannot detect
subsequent additions of links; therefore, the entire system must be built
before it is assigned to the {\tt dmIntegrator} object and no changes can be
made after this point. 

Specification of an inertial coordinate system other that the origin can be
specified by calling {\tt setRefSystem} and passing the position and
orientation (relative to the origin) of the new coordinate system. {\em I am
not really sure if this necessary from an efficiency standpoint, but it makes
it much more flexible in specifying systems} The functions, {\tt rtxFromICS}
and {\tt rtxToICS}, are used to rotate free vectors from one system to the
other.

The {\tt forwardKinematics} function computes the homogeneous transformation
matrix (4x4) describing the position (last column) and orientation (upper left
3x3 submatrix) of a particular link identified by articulation and link indices
with respect to the inertia coordinate system.  The function returns {\tt true}
if the indices were valid and the result is in {\tt mat}; otherwise, it returns
{\tt false} and the result in {\tt mat} is undefined.  If the homogeneous
transformation matrix of the reference member is desired the link index is to
be set to -1.

The {\tt ABDynamics} function is the heart of the DynaMechs library and
performs the Articulated Body (AB) dynamics computation for the multibody
system.  It takes, as input, the state vector {\tt qy} (for all of the links)
and computes the derivative of state vector, {\tt qdy}.  This
is the derivative function that the {\tt dmIntegrator} object uses to
perform the numerical integration.

See also: {\tt dmArticulation, dmIntegrator}.  */

//======================================================================

class DM_DLL_API dmSystem : public dmObject
{
public:
   ///
   dmSystem();
   ///
   virtual ~dmSystem();

   ///
   virtual unsigned int getNumDOFs() const = 0;
   ///
   virtual void setState(Float q[], Float qd[]) = 0;
   ///
   virtual void getState(Float q[], Float qd[]) const = 0;

   ///
   void makeJointVariable(Float **joint_var);
   ///
   int makeStateVariable(Float **state_var);
   ///
   void initSimVars(Float *qy, Float *qdy);

   // transformation functions
   ///
   void setRefSystem(Quaternion quat, CartesianVector pos);
   ///
   void getRefSystem(Quaternion quat, CartesianVector pos) const;
   ///
   void getPose(RotationMatrix R, CartesianVector pos) const;

   ///
   inline void rtxFromICS(CartesianVector p_ICS, CartesianVector p_ref) const;
   ///
   inline void   rtxToICS(CartesianVector p_ref, CartesianVector p_ICS) const;

   ///
   bool forwardKinematics(unsigned int link_index,
                          HomogeneousTransformationMatrix mat);

   ///
   virtual bool forwardKinematics(unsigned int link_index,
                                  dmABForKinStruct *fk) = 0;

   // AB dynamics algorithm
   ///
   virtual void ABDynamics(Float *qy, Float *qdy);

   virtual void draw() = 0;

protected:
   // not implemented
   dmSystem(const dmSystem &);
   dmSystem &operator=(const dmSystem &);

   // AB algorithm recursions:
   virtual void ABForwardKinematics(Float q[], Float qd[],
                                    dmABForKinStruct *ref_val) = 0;
   virtual void ABBackwardDynamics() = 0;
   virtual void ABForwardAccelerations(SpatialVector a_ref,
                                       Float qd[], Float qdd[]) = 0;

   void forwardKinematics(dmABForKinStruct *fk);

protected:
   // description of transform to reference system
   Quaternion      m_quat_ICS;
   RotationMatrix  m_R_ICS;     // pose of links wrt ICS - ^{ICS}R_{i}
   CartesianVector m_p_ICS;     // pos. of links wrt ICS - ^{ICS}p_{i}

private:
   // preallocated ABDynamics() simulation temporary variables.
   dmABForKinStruct m_ref_val;
   SpatialTensor    m_I_star_ref;
   SpatialVector    m_beta_star_ref;
   SpatialVector    m_accel_ref;
};

//----------------------------------------------------------------------------
//    Summary: 3D rotational transformation from ICS to ref mem CS
// Parameters: p_ICS - 3-vector expressed in the ICS
//    Returns: p_ref - 3-vector expressed in ref mem's CS
//----------------------------------------------------------------------------
inline void dmSystem::rtxFromICS(CartesianVector p_ICS,
                                 CartesianVector p_ref) const
{
   p_ref[0] = m_R_ICS[0][0]*p_ICS[0] + m_R_ICS[0][1]*p_ICS[1] +
      m_R_ICS[0][2]*p_ICS[2];
   p_ref[1] = m_R_ICS[1][0]*p_ICS[0] + m_R_ICS[1][1]*p_ICS[1] +
      m_R_ICS[1][2]*p_ICS[2];
   p_ref[2] = m_R_ICS[2][0]*p_ICS[0] + m_R_ICS[2][1]*p_ICS[1] +
      m_R_ICS[2][2]*p_ICS[2];
}

//----------------------------------------------------------------------------
//    Summary: 3D rotational transformation from ref mem CS to ICS
// Parameters: p_ref - 3-vector expressed in ref mem's CS
//    Returns: p_ICS - 3-vector expressed in the ICS
//----------------------------------------------------------------------------
inline void dmSystem::rtxToICS(CartesianVector p_ref,
                               CartesianVector p_ICS) const
{
   p_ICS[0] = m_R_ICS[0][0]*p_ref[0] + m_R_ICS[1][0]*p_ref[1] +
      m_R_ICS[2][0]*p_ref[2];
   p_ICS[1] = m_R_ICS[0][1]*p_ref[0] + m_R_ICS[1][1]*p_ref[1] +
      m_R_ICS[2][1]*p_ref[2];
   p_ICS[2] = m_R_ICS[0][2]*p_ref[0] + m_R_ICS[1][2]*p_ref[1] +
      m_R_ICS[2][2]*p_ref[2];
}

#endif
