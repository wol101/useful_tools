/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegRK45.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Embedded 4th/5th order adaptive-step Runge Kutta integrator
 *****************************************************************************/

#include <dm.h>
#include <dmIntegRK45.hpp>

//----------------------------------------------------------------------------
dmIntegRK45::dmIntegRK45()
      : dmIntegrator(),
        m_qy(NULL),
        m_qdy(NULL),
        m_qdy2(NULL),
        m_qdy3(NULL),
        m_qdy4(NULL),
        m_qdy5(NULL),
        m_qdy6(NULL),
        m_qy_temp(NULL),
        m_qy_error(NULL),
        m_qy_scale(NULL),
        lasth(0.0)
{
}

//----------------------------------------------------------------------------
dmIntegRK45::~dmIntegRK45()
{
   if (m_system)
   {
      // deallocate any state variables.
      if (m_qy)
      {
         delete m_qy;
         delete m_qdy;
         delete m_qdy2;
         delete m_qdy3;
         delete m_qdy4;
         delete m_qdy5;
         delete m_qdy6;
         delete m_qy_temp;
         delete m_qy_error;
         delete m_qy_scale;
      }
   }
}

//----------------------------------------------------------------------------
bool dmIntegRK45::allocateStateVariables()
{
   // deallocation of any preexisting simulation variables is done in
   // dmSystem::makeStateVariable 

   // allocate new ones
   m_num_state_vars = m_system->makeStateVariable(&m_qy);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy);

   m_num_state_vars = m_system->makeStateVariable(&m_qdy2);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy3);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy4);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy5);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy6);

   m_num_state_vars = m_system->makeStateVariable(&m_qy_temp);
   m_num_state_vars = m_system->makeStateVariable(&m_qy_error);

   m_num_state_vars = m_system->makeStateVariable(&m_qy_scale);

   m_system->initSimVars(m_qy, m_qdy);

   if (m_num_state_vars == 0)
   {
      return true;
   }

   if (m_num_state_vars &&
       m_qy && m_qdy && m_qy_temp &&
       m_qdy2 && m_qdy3 && m_qdy4 && m_qdy5 && m_qdy6 &&
       m_qy_error && m_qy_scale)
   {
      return true;
   }

   return false;
}

//----------------------------------------------------------------------------
void dmIntegRK45::rkck(Float h)
{
   //const Float a2=0.2, a3=0.3, a4=0.6, a5=1.0, a6=0.875;

   const Float b21=(Float)0.2;
   const Float b31=(Float)(3.0/40.0), b32=(Float)(9.0/40.0);
   const Float b41=(Float)(0.3), b42=(Float)(-0.9), b43=(Float)(1.2);
   const Float b51=(Float)(-11.0/54.0), b52=(Float)(2.5),
               b53=(Float)(-70.0/27.0), b54=(Float)(35.0/27.0);
   const Float b61=(Float)(1631.0/55296.0), b62=(Float)(175.0/512.0),
               b63=(Float)(575.0/13824.0);
   const Float b64=(Float)(44275.0/110592.0), b65=(Float)(253.0/4096.0);

   const Float c1=(Float)(37.0/378.0), c3=(Float)(250.0/621.0),
               c4=(Float)(125.0/594.0), c6=(Float)(512.0/1771.0);

   const Float dc1=c1-(Float)(2825.0/27648.0), dc3=c3-(Float)(18575.0/48384.0);
   const Float dc4=c4-(Float)(13525.0/55296.0), dc5=(Float)(-277.0/14336.0);
   const Float dc6=c6-(Float)(0.25);

   int j;
   Float h1,h2,h3,h4,h5,h6;

   // ============= Step I. =============
   h1=b21*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + h1*m_qdy[j];
   }
   m_system->ABDynamics(/*t+a2*h,*/ m_qy_temp, m_qdy2);

   // ============= Step II. =============
   h1=b31*h;
   h2=b32*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + (h1*m_qdy[j] + h2*m_qdy2[j]);
   }
   m_system->ABDynamics(/*t+a3*h,*/ m_qy_temp, m_qdy3);

   // ============= Step III. =============
   h1=b41*h;
   h2=b42*h;
   h3=b43*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + (h1*m_qdy[j] + h2*m_qdy2[j] + h3*m_qdy3[j]);
   }
   m_system->ABDynamics(/*t+a4*h,*/ m_qy_temp, m_qdy4);

   // ============= Step IV. =============
   h1=b51*h;
   h2=b52*h;
   h3=b53*h;
   h4=b54*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + (h1*m_qdy[j]  + h2*m_qdy2[j] +
                                h3*m_qdy3[j] + h4*m_qdy4[j]);
   }
   m_system->ABDynamics(/*t+a5*h,*/ m_qy_temp, m_qdy5);

   // ============= Step V. =============
   h1=b61*h;
   h2=b62*h;
   h3=b63*h;
   h4=b64*h;
   h5=b65*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + (h1*m_qdy[j]  + h2*m_qdy2[j] + h3*m_qdy3[j] +
                                h4*m_qdy4[j] + h5*m_qdy5[j]);
   }
   m_system->ABDynamics(/*t+a6*h,*/ m_qy_temp, m_qdy6);

   // ============= Step VI (beginning). =============
   h1=c1*h;
   h3=c3*h;
   h4=c4*h;
   h6=c6*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_temp[j] = m_qy[j] + (h1*m_qdy[j]  + h3*m_qdy3[j] +
                                h4*m_qdy4[j] + h6*m_qdy6[j]);
   }
  
   // ============= Error Estimate. =============
   h1=dc1*h;
   h3=dc3*h;
   h4=dc4*h;
   h5=dc5*h;
   h6=dc6*h;
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy_error[j] = h1*m_qdy[j] + h3*m_qdy3[j] + h4*m_qdy4[j] +
         h5*m_qdy5[j] + h6*m_qdy6[j];
   }
}

//----------------------------------------------------------------------------
void dmIntegRK45::rkqs(Float htry, Float eps, Float *hdid, Float *hnext)
{
   const Float SAFETY =  (Float) 0.9;
   const Float PGROW  =  (Float)-0.2;
   const Float PSHRNK =  (Float)-0.25;
   const Float ERRCON =  (Float) 1.89e-4; // pow(5/SAFETY,1/PGROW)

   int j;
   Float h, err=0.0, errmax, hscale;

   h=htry;
   for (;;)
   {
      rkck(h);
      errmax=0.0;
      for (j=0; j<m_num_state_vars; ++j)
      {
         err = m_qy_error[j]/m_qy_scale[j];
         if (err < 0.0) err=-err;
         if (err > errmax) errmax = err;
      }

      errmax /= eps;

      cout << "  h = " << h << ", errmax = " << errmax << endl;
      
      if (errmax <= 1.0)
      {
         break;
      }

      hscale = SAFETY*pow(errmax,(float)PSHRNK);
      if (hscale < 0.1)
      {
         hscale=(Float)0.1;
      }
      h *= hscale;
      //tnew = t+h
      //if (tnew==t) //error, stepsize underflow
   }

   if (errmax > ERRCON)
   {
      cout << " >ERRCON: " << *hnext << "->";
      *hnext = SAFETY*h*pow(errmax,PGROW);
      cout << *hnext << endl;
   }
   else
   {
      cout << " <=ERRCON: " << *hnext << "->";
      *hnext = 2.0*h;
      cout << *hnext << endl;
   }
   *hdid = h;

   cerr << "hnext = " << *hnext << endl;

   // ============ Step VI. Final Derivative Evaluation ==========
   for (j=0; j<m_num_state_vars; ++j)
   {
      m_qy[j] = m_qy_temp[j];
   }

   // t += *hdid
   m_system->ABDynamics(/*t,*/ m_qy, m_qdy);
}



//----------------------------------------------------------------------------
//   Function: simulateRK45
//    Summary: simulate system from current time, t, to next time t+h with
//             one Adaptive 5th order Cash-Karp Runge-Kutta iteration.
// Parameters: desired integration stepsize
//    Returns: actual step size
//----------------------------------------------------------------------------
void dmIntegRK45::simulate(Float &delta_t)
{
   const int MAXSTP = 400;
   const Float TINY = (Float)1.0e-10; // 1.0; //1e-30;
   const Float EPS  = (Float)1.0e-4;

   Float t = 0;
   Float h;

   int nstp, j;
   int nok = 0, nbad = 0;

   if (!lasth)
   {
      lasth = delta_t;
   }
   if (lasth > delta_t)
   {
      lasth = delta_t;
   }

   // while (t<delta_t && nstp<MAXSTP)
   for (nstp = 0; nstp < MAXSTP; ++nstp)
   {
      Float hdid;
      h = lasth;
      for (j=0; j<m_num_state_vars; ++j)
      {
         m_qy_scale[j] = fabs(m_qy[j])+fabs(m_qdy[j]*h)+TINY;
      }

      if (t+h>delta_t) h=delta_t-t;

      rkqs(h, EPS, &hdid, &lasth);

      if (h==hdid) ++nok;
      else ++nbad;

      t+=hdid;
      if (t>=delta_t)
      {
         delta_t = t;
#if 1
         cerr << "t = " << t << " simulateAdaptiveRK steps (ok/bad): (" << nok
              << "/" << nbad << "), idt = " << delta_t << endl;
#endif
         return;
      }
   }

   cerr << "dmIntegRK45::simulate() error: Too many steps " << endl;
   lasth = delta_t;
}
