/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmLink.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class definitions for dmLink.
 *****************************************************************************/

#ifndef _DM_LINK_HPP
#define _DM_LINK_HPP

#include <dm.h>
#include <dmObject.hpp>

//============================================================================
/**

The {\tt dmLink} class is an abstract base class for all derived link classes.
Its main purpose is to support polymorphism across all link classes by
providing the virtual interfaces for all the functions that the {\tt
dmArticulation} class calls in the course of simulating the system.  As such,
nearly all functions specified in the public section are pure virtual functions
that must be defined in the derived link classes (currently, {\tt dmMDHLink},
{\tt dmSphericalLink}, {\tt dmMobileBaseLink}, and {\tt dmZScrewTxLink}).

The link's state variables (generalized position and velocity variables) can be
set and retreived using the {\tt setState} and {\tt getState} functions.  The
{\tt q} and {\tt qd} arguments correspond to position and velocity,
respectively.  They are arrays containing $n$ elements where $n$ is the number
of degrees of freedom for this particular type of link (and determined by the
derived classes).  This number is returned when the {\tt getNumDOFs} function
is called.  The joint input vector (containing motor inputs where applicable,
but usually generalized joint forces) can be set by calling {\tt
setJointInput}.  The parameter is also an array of {\tt getNumDOFs} elements
containing the desired values.

A coulomb friction parameter can also be specified and retrieved using the {\tt
setJointFriction} and {\tt getJointFriction} functions.  This scalar parameters
multiplies the joint velocity to produce a force/torque opposing the direction
of motion as follows:
\begin{eqnarray*}
\tau & = & \mu_c \: \dot{q}.
\end{eqnarray*}

For dynamics simulation of the link using the AB algorithm, a number of
transformation functions are required of all link types.  Their functions are
listed as follows:
\begin{center}
\begin{tabular}{lcl}
{\tt rtxToInboard}  & ~~~ & $^{i-1}f_i = {^iR}^T_{i-1} \: f_i$ \\
{\tt rtxFromInboard}     && $^{i}\omega_{i-1} = {^iR}_{i-1} \: \omega_{i-1}$ \\
{\tt stxToInboard}       && $^{i-1}{\bf f}_i = {^iX}^T_{i-1} \: {\bf f}_i$ \\
{\tt stxFromInboard}     && $^i{\bf v}_{i-1} = {^iX}_{i-1} \: {\bf v}_{i-1}$ \\
{\tt rcongtxToInboardSym}&& $^{i-1}\bar{I}_i =
                      {^iR}^T_{i-1} \: \bar{I}_i \: {^iR}_{i-1}$ \\
{\tt rcongtxToInboardGen}&& $^{i-1}G_i =
                      {^iR}^T_{i-1} \: G_i \: {^iR}_{i-1}$ \\
{\tt scongtxToInboardIrefl} && $^{i-1}{\bf N}_i =
                      {^i{X}}^T_{i-1} \: {\bf N}_i \: {^i{X}}_{i-1}$ \\
\end{tabular}
\end{center}
The first two rotate Cartesian vectors between this link's and the inboard
(parent) link's coordinate systems, while the second two transform (rotate and
translate) spatial vectors.  The last three functions perform congruence
transformations on matrices to the inboard coordinate system.  {\tt
rcongtxToInboardSym} affects a rotational congruence transform on sysmmetric
$3\times 3$ matrices while its counterpart, {\tt rcongtxToInboardGen},
transforms general $3\times 3$ matrices.  The last function, {\tt
scongtxToInboardIrefl}, is a specialized function for the AB algorithm which
efficiently transforms $6\times 6$ reflected articulated-body inertia matrices
taking into account special structure of the matrix based on its joint axes.
This one function is the centerpiece of the efficiency of this implementation
of the AB algorithm.

The next four functions are used to perform the three recursions of the AB
simulation algorithm.  The first forward kinematics recursion is implemented
for each link with the {\tt ABForwardKinematics} function.  This function
should only be called by {\tt dmArticulation::ABForwardKinematics} {\em yeah,
this should be private and {\tt dmArticulation} should be made a friend}.
Again, the {\tt q} and {\tt qd} parameters are the joint position and velocity
vectors computed by the current interation of the numerical integration
algorithm and are used to set the new state of the link.  The {\tt
link\_val\_inboard} is the {\tt ABForKinStruct} (see {\tt dmArticulation}) that
has been filled with the values for the inboard link's state dependent
quantities.  Using these values, the {\tt link\_val\_curr} struct elements are
computed for this link.

The second backward recursion of the AB algorithm is implemented with two
different functions for reasons of efficiency.  If this link has no children,
it is a leaf node in the tree structure, and therefore, the {\tt
dmArticulation::ABBackwardDynamics} function will call the {\tt
ABBackwardDynamicsN} function which will begin the recursion which requires
less computation, by computing {\tt f\_star\_inboard} and {\tt
N\_refl\_inboard}, the AB bias force and inertia that are reflected across this
link's joint and transformed to the inboard link's coordinate system.  The
function {\tt ABBackwardDynamics} performs a full recursive step for a link
with children.  It takes the accumulated results of the child links in {\tt
f\_star\_curr} and {\tt N\_refl\_curr} and computes the same quantities as
before.  The {\tt ABForKinStruct} parameter is the {\tt link\_val\_curr}
computed in the first pass, and is used to call {\tt dmForce::computeForce()}
functions if they have been added to the associated dmRigidBody.

The third forward recursion of the AB algorithm is implemented in the {\tt
ABForwardAcceleration} function.  Its input parameter, {\tt a\_inboard} is the
spatial acceleration of the inboard link.  This function computes and outputs
the spatial acceleration of this link in {\tt a\_curr} and fills in the
derivative of state variables ({\tt qd} and {\tt qdd}).  Note that the velocity
vector, {\tt qd}, is not necessarily the same as that used in {\tt
ABForwardKinematics}.  Rather, it contains the time derivatives of {\tt q}.
See {\tt dmSphericalLink} for an example where they are not the same. 

The only function that is implemented in this class is the {\tt
forwardKinematics} function.  It is called by {\tt
dmArticulation::forwardKinematics} function and computes the current link's
position ({\tt link\_val\_curr->p\_ICS}) and orientation ({\tt
link\_val\_curr->R\_ICS}) with respect to the inertial coordinate frame given
the inboard link's position and orientation ({\tt link\_val\_inboard->p\_ICS}
and {\tt link\_val\_inboard->R\_ICS}).

See also: {\tt dmArticulation}, {\tt dmMDHLink}, {\tt dmSphericalLink},
          {\tt dmZScrewTxLink}, {\tt dmMobileBaseLink}.

 */

class DM_DLL_API dmLink : public dmObject
{
public:
   ///
   dmLink();
   ///
   virtual ~dmLink();

   ///
   virtual int getNumDOFs() const = 0;
   ///
   virtual void setState(Float q[], Float qd[]) = 0;
   ///
   virtual void getState(Float q[], Float qd[]) const = 0;
   ///
   virtual void getPose(RotationMatrix R, CartesianVector p) const = 0;

   ///
   virtual void setJointInput(Float joint_input[]) = 0;

   ///
   Float getJointFriction() const {return m_joint_friction;}
   ///
   void setJointFriction(Float u_c) {m_joint_friction = u_c;}

// Link-to-link transformation functions:
   ///
   virtual void rtxToInboard(CartesianVector curr,
                             CartesianVector prev) const = 0;
   ///
   virtual void rtxFromInboard(CartesianVector prev,
                               CartesianVector curr) const = 0;
   ///
   virtual void stxToInboard(SpatialVector curr,
                             SpatialVector prev) const = 0;
   ///
   virtual void stxFromInboard(SpatialVector prev,
                               SpatialVector curr) const = 0;
   ///
   virtual void rcongtxToInboardSym(CartesianTensor Curr,
                                    CartesianTensor Prev) const = 0;
   ///
   virtual void rcongtxToInboardGen(CartesianTensor Curr,
                                    CartesianTensor Prev) const = 0;
   ///
   virtual void scongtxToInboardIrefl(SpatialTensor N_curr,
                                      SpatialTensor N_prev) const = 0;

// Articulated-Body (AB) algorithm functions:
   ///
   virtual void ABForwardKinematics(Float q[],
                                    Float qd[],
                                    dmABForKinStruct *link_val_inboard,
                                    dmABForKinStruct *link_val_curr) = 0;

   ///
   virtual void ABBackwardDynamics(dmABForKinStruct *link_val_curr,
                                   SpatialVector f_star_curr,
                                   SpatialTensor N_refl_curr,
                                   SpatialVector f_star_inboard,
                                   SpatialTensor N_refl_inboard) = 0;
   ///
   virtual void ABBackwardDynamicsN(dmABForKinStruct *link_val_curr,
                                    SpatialVector f_star_inboard,
                                    SpatialTensor N_refl_inboard) = 0;

   ///
   virtual void ABForwardAccelerations(SpatialVector a_inboard,
                                       SpatialVector a_curr,
                                       Float qd[],
                                       Float qdd[]) = 0;

// Generic forward kinematics algorithm functions:
   ///
   void forwardKinematics(dmABForKinStruct *link_val_inboard,
                          dmABForKinStruct *link_val_curr);

// rendering functions:
   ///
   virtual void draw() = 0;

protected:
   // not implemented
   dmLink(const dmLink &);
   dmLink &operator=(const dmLink &);

protected:
   CartesianVector m_p;   // position of this link's CS wrt inboard link.

   bool  m_joint_limit_flag;      // define dynamic behavior when joint
   Float m_joint_limit_spring;    // limits are reached.
   Float m_joint_limit_damper;
   Float m_joint_friction;        // Coulomb(?) friction coefficient.

   SpatialVector m_zeta;          // Additional variables for the AB algorithm
   SpatialTensor m_N_refl;        // member functions that are not
   SpatialVector m_gamma;         // dependent on the joint type.
};

#endif
