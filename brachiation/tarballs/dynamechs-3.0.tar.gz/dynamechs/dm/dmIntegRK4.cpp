/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegRK4.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: 4th order fixed-step Runge Kutta integrator
 *****************************************************************************/

#include <dm.h>
#include <dmIntegRK4.hpp>

//----------------------------------------------------------------------------
dmIntegRK4::dmIntegRK4()
      : dmIntegrator(),
        m_qy(NULL),
        m_qdy(NULL),
        m_qyt(NULL),
        m_qdyt(NULL),
        m_qdym(NULL),
        m_qdyb(NULL)
{
}

//----------------------------------------------------------------------------
dmIntegRK4::~dmIntegRK4()
{
   if (m_system)
   {
      // deallocate any state variables.
      if (m_qy)
      {
         delete m_qy;
         delete m_qdy;
         delete m_qyt;
         delete m_qdyt;
         delete m_qdym;
         delete m_qdyb;
      }
   }
}

//----------------------------------------------------------------------------
bool dmIntegRK4::allocateStateVariables()
{
   // deallocation of any preexisting simulation variables is done in
   // dmSystem::makeStateVariable 

   // allocate new ones
   m_num_state_vars = m_system->makeStateVariable(&m_qy);
   m_num_state_vars = m_system->makeStateVariable(&m_qdy);

   m_num_state_vars = m_system->makeStateVariable(&m_qyt);
   m_num_state_vars = m_system->makeStateVariable(&m_qdyt);
   m_num_state_vars = m_system->makeStateVariable(&m_qdym);
   m_num_state_vars = m_system->makeStateVariable(&m_qdyb);

   m_system->initSimVars(m_qy, m_qdy);

   if (m_num_state_vars == 0)
   {
      return true;
   }

   if (m_num_state_vars &&
       m_qy && m_qdy && m_qyt && m_qdyt && m_qdym && m_qdyb)
   {
      return true;
   }

   return false;
}

//----------------------------------------------------------------------------
//   Function: simulateRK4
//    Summary: simulate system from current time, t, to next time t+h with
//             one RK4 iteration.
// Parameters: fixed integration stepsize
//    Returns: nothing
//----------------------------------------------------------------------------
void dmIntegRK4::simulate(Float &delta_t)
{
   register int j;

   Float h2 = delta_t/2.0;
   Float h6 = delta_t/6.0;

// Step 1. Forward Euler half step across interval [t, t+h).
   // Again assume m_qy, m_ry match the internal state and m_qdy and m_rdy are
   // the corresponding derivative of state vectors
   for (j = 0; j < m_num_state_vars; j++)
   {
      m_qyt[j] = m_qy[j] + h2*m_qdy[j];
   }

   // derfun(t+h/2,&tq[tqindx][0][0], m_qyt, m_qdyt, m_ryt, m_rdyt);
   m_system->ABDynamics(m_qyt, m_qdyt);

// Step 2.
   for (j = 0; j < m_num_state_vars; j++)
   {
      m_qyt[j] = m_qy[j] + h2*m_qdyt[j];
   }

   // derfun(t+h/2,&tq[tqindx][0][0],m_qyt, m_qdym, m_ryt, m_rdym);
   m_system->ABDynamics(m_qyt, m_qdym);

// Step 3.
   for (j = 0; j < m_num_state_vars; j++)
   {
      m_qyt[j] = m_qy[j] + delta_t*m_qdym[j];
      m_qdym[j] += m_qdyt[j];
   }

   // derfun(t+h, &tq[tqindx+tqskip][0][0], m_qyt, m_qdyb, m_ryt, m_rdyb);
   m_system->ABDynamics(m_qyt, m_qdyb);

// Step 4. accumulate results.
   for (j = 0; j < m_num_state_vars; j++)
   {
      m_qy[j] += h6*(m_qdy[j] + m_qdyb[j] + 2.0*m_qdym[j]);
   }

   // derfun(t+h,&tq[tqindx+tqskip][0][0],m_qy,m_qdy,m_ry,m_rdy);
   m_system->ABDynamics(m_qy, m_qdy);
}
