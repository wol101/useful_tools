/*****************************************************************************
 * Copyright 1997, Scott McMillan
 *****************************************************************************
 *     File: gldraw.cpp
 *   Author: Scott McMillan
 *  Created: 24 March 1997
 *  Summary: 
 *****************************************************************************/

#include <dm.h>
#include <dmArticulation.hpp>
#include <dmLink.hpp>
#include <dmZScrewTxLink.hpp>
#include <dmMobileBaseLink.hpp>
#include <dmSphericalLink.hpp>
#include <dmMDHLink.hpp>
#include <dmRevoluteLink.hpp>
#include <dmPrismaticLink.hpp>
#include <dmContactModel.hpp>
#include <dmEnvironment.hpp>

#include <GL/gl.h>

//============================================================================
// Initialize DynaMechs/OpenGL drawing routines
//============================================================================

//----------------------------------------------------------------------------
void dmEnvironment::drawInit()
{
   register int i, j;

   GLfloat vertex[3][3], normal[3];

   // read in and allocate depth data

   m_terrain_model_index = glGenLists(1);

   if (m_terrain_model_index == 0)
   {
      cerr << "loadModel_grid: Error unable to allocate dlist index." << endl;
   }

   glNewList(m_terrain_model_index, GL_COMPILE);
   {
      glPolygonMode(GL_FRONT, GL_LINE); //FILL);
      glPolygonMode(GL_BACK, GL_LINE);

      GLfloat color[4] = {0.5,0.5,1.0,1.0};
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, color);

      for (j=0; j<y_dim-1; j++)
      {
         glBegin(GL_TRIANGLE_STRIP);
         {
            for (i=0; i<x_dim; i++)
            {
               vertex[0][0] = ((GLfloat) i)*grid_resolution;
               vertex[0][1] = ((GLfloat) j + 1.0)*grid_resolution;
               vertex[0][2] = depth[i][j+1];

               if (i > 0)
               {
                  vertex[1][0] = ((GLfloat) i - 1.0)*grid_resolution;
                  vertex[1][1] = ((GLfloat) j + 1.0)*grid_resolution;
                  vertex[1][2] = depth[i-1][j+1];

                  vertex[2][0] = ((GLfloat) i - 1.0)*grid_resolution;
                  vertex[2][1] = ((GLfloat) j)*grid_resolution;
                  vertex[2][2] = depth[i-1][j];

                  compute_face_normal(vertex[1], vertex[2], vertex[0], normal);
                  glNormal3fv(normal);
               }
               glVertex3fv(vertex[0]);

               vertex[1][0] = ((GLfloat) i)*grid_resolution;
               vertex[1][1] = ((GLfloat) j)*grid_resolution;
               vertex[1][2] = depth[i][j];

               if (i > 0)
               {
                  compute_face_normal(vertex[1], vertex[0], vertex[2], normal);
                  glNormal3fv(normal);
               }
               glVertex3fv(vertex[1]);
            }
         }
         glEnd();
      }
   }
   glEndList();
}

//============================================================================
// draw environment and robot
//============================================================================

//----------------------------------------------------------------------------
void dmArticulation::draw()
{
   glPushMatrix();

   glTranslatef(m_p_ICS[XC], m_p_ICS[YC], m_p_ICS[ZC]);

   float len = sqrt(m_quat_ICS[0]*m_quat_ICS[0] + 
                    m_quat_ICS[1]*m_quat_ICS[1] + 
                    m_quat_ICS[2]*m_quat_ICS[2]);
   if (len > 1.0e-6)
   {
      float angle = 2.0*atan2(len, m_quat_ICS[3]);
      glRotatef(angle*RADTODEG,
                m_quat_ICS[0]/len, m_quat_ICS[1]/len, m_quat_ICS[2]/len);
   }

   // render some sort of base element
   if (getUserData())
      glCallList(*((GLuint *) getUserData()));

   for (unsigned int j=0; j<m_link_list.size(); j++)
   {
      if (m_link_list[j]->parent == NULL)
      {
         glPushMatrix();

         // draw base link
         m_link_list[j]->link->draw();

         // recurse through the children
         for (unsigned int i=0; i<m_link_list[j]->child_list.size(); i++)
         {
            glPushMatrix();
            drawTraversal(m_link_list[j]->child_list[i]);
            glPopMatrix();
         }

         glPopMatrix();
      }
   }

   glPopMatrix();
}

//----------------------------------------------------------------------------
void dmArticulation::drawTraversal(LinkInfoStruct *node)
{
   if (node && node->parent)
   {
      node->link->draw();

      for (unsigned int i=0; i<node->child_list.size(); i++)
      {
         if (node->child_list.size() > 1)
         {
            glPushMatrix();
            drawTraversal(node->child_list[i]);
            glPopMatrix();
         }
         else
         {
            drawTraversal(node->child_list[i]);
         }
      }
   }
}


//----------------------------------------------------------------------------
void dmZScrewTxLink::draw()
{
   glTranslatef(0.0, 0.0, m_dMDH);
   glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);
}

//----------------------------------------------------------------------------
void dmRevoluteLink::draw()
{
   // set static portion of the MDH transformation.
   if (m_alphaMDH != 0.0)
   {
      glRotatef(m_alphaMDH*RADTODEG, 1.0, 0.0, 0.0);
   }

   if ((m_aMDH != 0.0) || (m_dMDH != 0.0))
   {
      glTranslatef(m_aMDH, 0.0, m_dMDH);
   }

   // set dynamic z-axis transformation.
   glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmPrismaticLink::draw()
{
   // set static portion of the MDH transformation.
   if (m_alphaMDH != 0.0)
   {
      glRotatef(m_alphaMDH*RADTODEG, 1.0, 0.0, 0.0);
   }

   if ((m_aMDH != 0.0) || (m_dMDH != 0.0))
   {
      glTranslatef(m_aMDH, 0.0, m_dMDH);
   }

   if (m_thetaMDH != 0.0)
   {
      glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);
   }

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmSphericalLink::draw()
{
   glTranslatef(m_p[0], m_p[1], m_p[2]);
   glRotatef(m_q[2]*RADTODEG, 0.0, 0.0, 1.0);
   glRotatef(m_q[1]*RADTODEG, 0.0, 1.0, 0.0);
   glRotatef(m_q[0]*RADTODEG, 1.0, 0.0, 0.0);

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::draw()
{
   glTranslatef(m_p[XC], m_p[YC], m_p[ZC]);

   float len = sqrt(m_quat[0]*m_quat[0] + 
                    m_quat[1]*m_quat[1] + 
                    m_quat[2]*m_quat[2]);
   if (len > 1.0e-6)
   {
      float angle = 2.0*atan2(len, m_quat[3]);
      glRotatef(angle*RADTODEG, m_quat[0]/len, m_quat[1]/len, m_quat[2]/len);
   }

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmContactModel::draw()
{
}

//----------------------------------------------------------------------------
void dmEnvironment::draw()
{
   glCallList(m_terrain_model_index);
}
