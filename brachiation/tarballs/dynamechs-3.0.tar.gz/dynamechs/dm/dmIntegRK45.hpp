/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegRK45.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Embedded 4th/5th order adaptive step size Runge Kutta
 *****************************************************************************/

#ifndef _DM_INTEG_RK45_HPP
#define _DM_INTEG_RK45_HPP

#include <dm.h>
#include <dmIntegrator.hpp>

//============================================================================

/**

This class is under major construction and is virtually untested.

This is a concrete integrator class derived from the {\tt dmIntegrator} class,
which implements an embedded fourth/fifth order, adaptive stepsize Runge-Kutta
integration algorithm.  Note that in the process, six calls to the associated
{\tt dmSystem::ABDynamics} function will be made.  The {\tt idt} parameter
corresponds to the amount of time that should be simulated, but not necessarily
the size of the step that is taken with a single iteration of
the algorithm.

I have only just started playing with this algorithm.  Many of the quality
control parameters need to be set-able by the user, but currently no accessor
functions have been provided.  Initial tests of the algorithm show that it
cannot handle steps across collision boundaries very well.  This may be
overcome with an, as yet, unknown set of control parameters.

 */

//======================================================================

class DM_DLL_API dmIntegRK45 : public dmIntegrator
{
public:
   ///
   dmIntegRK45();
   ///
   virtual ~dmIntegRK45();

   ///
   void simulate(Float &delta_t);

private:
   // not implemented
   dmIntegRK45(const dmIntegRK45 &);
   dmIntegRK45 &operator=(const dmIntegRK45 &);


   void rkck(Float h);
   void rkqs(float htry, float eps, float *hdid, float *hnext);

   bool allocateStateVariables();

private:
   // RK45 state and derivative variables
   Float *m_qy;
   Float *m_qdy;

   Float *m_qdy2;
   Float *m_qdy3;
   Float *m_qdy4;
   Float *m_qdy5;
   Float *m_qdy6;

   Float *m_qy_temp;
   Float *m_qy_error;
   Float *m_qy_scale;

   Float lasth;
};

#endif
