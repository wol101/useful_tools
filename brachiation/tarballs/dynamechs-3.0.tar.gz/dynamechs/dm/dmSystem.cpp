/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmSystem.cpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class definitions for dmSystem
 *****************************************************************************/

#include <dm.h>
#include <dmSystem.hpp>
#include <dmEnvironment.hpp>

//============================================================================
// class dmSystem : public dmObject
//============================================================================

//----------------------------------------------------------------------------
//    Summary: default dmSystem constructor initializes an empty (invalid)
//             system.
// Parameters: none.
//    Returns: none.
//----------------------------------------------------------------------------
dmSystem::dmSystem() : dmObject()
{
   Quaternion q = {0., 0., 0., 1.};
   CartesianVector p = {0., 0., 0.};
   setRefSystem(q,p);

   for (unsigned int i=0; i<6; i++)
      m_ref_val.v[i] = 0.0;
}


//----------------------------------------------------------------------------
//    Summary: Destructor for dmSystem class.  Deallocates all of the
//             dynamically allocated variables and objects allocated by this
//             class.
// Parameters: none.
//    Returns: none.
//----------------------------------------------------------------------------
dmSystem::~dmSystem()
{
}

//----------------------------------------------------------------------------
//    Summary: add a reference member to the system
// Parameters: a pointer to a previously allocated and initialized reference
//             member. 
//    Returns: TRUE if the operation is successful, else FALSE (when the
//             pointer parameter is NULL). 
//----------------------------------------------------------------------------
void dmSystem::setRefSystem(Quaternion quat, CartesianVector pos)
{
   normalizeQuat(quat);
   m_quat_ICS[0] = quat[0];
   m_quat_ICS[1] = quat[1];
   m_quat_ICS[2] = quat[2];
   m_quat_ICS[3] = quat[3];

   m_p_ICS[0] = pos[0];
   m_p_ICS[1] = pos[1];
   m_p_ICS[2] = pos[2];

   buildRotMat(quat, m_R_ICS);
}

//----------------------------------------------------------------------------
void dmSystem::getRefSystem(Quaternion quat, CartesianVector pos) const
{
   quat[0] = m_quat_ICS[0];
   quat[1] = m_quat_ICS[1];
   quat[2] = m_quat_ICS[2];
   quat[3] = m_quat_ICS[3];

   pos[0] = m_p_ICS[0];
   pos[1] = m_p_ICS[1];
   pos[2] = m_p_ICS[2];
}

//----------------------------------------------------------------------------
void dmSystem::getPose(RotationMatrix R, CartesianVector pos) const
{
   for (unsigned int i=0; i<3; i++)
   {
      R[i][0] = m_R_ICS[i][0];
      R[i][1] = m_R_ICS[i][1];
      R[i][2] = m_R_ICS[i][2];

      pos[i]  = m_p_ICS[i];
   }
}

// ---------------------------------------------------------------------------
// Function : makeJointVariable
// Purpose  : make a one dimensional vector of Floats where the first index is
//            the number of DOFs in the system
// Inputs   : pointer to the one dimensional array
// Outputs  : pointer to the one dimensional array after allocation
// ---------------------------------------------------------------------------
void dmSystem::makeJointVariable(Float **joint_var)
{
   if (getNumDOFs() > 0)
   {
      *joint_var = new Float[getNumDOFs()];
   }
   else
   {
      *joint_var = NULL;
   }
}

//----------------------------------------------------------------------------
//    Summary: 
// Parameters: 
//    Returns: 
//----------------------------------------------------------------------------
int dmSystem::makeStateVariable(Float **state_var)
{
   unsigned int num_vars = getNumDOFs();

   // THE FOLLOWING IS INCORRECT
   //deallocate any existing variable
   //if (*state_var)
   //{
   //   delete *state_var;
   //}

   if (num_vars > 0)
   {
      num_vars *= 2;
      *state_var = new Float[num_vars];
   }

   return num_vars;
}

//----------------------------------------------------------------------------
//    Summary: initialize all of the variables needed for the numerical
//             integration algorithms.  Note that it queries the articulations
//             for the number of DOFS in each; therefore, all links should be
//             assigned to the articulations before this function is called.
// Parameters: none
//    Returns: none (I should check for valid allocation and return TRUE if
//             this function is successfully completed.
//----------------------------------------------------------------------------
void dmSystem::initSimVars(Float *qy, Float *qdy)
{
   unsigned int num_vars = getNumDOFs();

   getState(&qy[0], &qy[num_vars]);

   for (unsigned int j=0; j<num_vars; j++)
   {
      /* FIXME */
      // In the case of SphericalLinks
      // the following commented line incorrectly transfers angular velocity
      // components to Euler angle rates in derivative state vector.
      //
      // m_qdy[aindex + j] = m_qy[aindex + j+m_dofs_per_articulation[k]];
      //
      // for now I am setting the Euler angle rates to zero will be
      // incorrect for first iteration only if angular velocity is nonzero
      qdy[j] = 0.0;
      qdy[j + num_vars] = 0.0;
   }
}

//----------------------------------------------------------------------------
//   Function: forwardKinematics
void dmSystem::forwardKinematics(dmABForKinStruct *fk)
{
   register int i, j;

   for (i = 0; i < 3; i++)
   {
      fk->p_ICS[i] = m_p_ICS[i];
      for (j = 0; j < 3; j++)
      {
         fk->R_ICS[i][j] = m_R_ICS[j][i];
      }
   }
}

//----------------------------------------------------------------------------
//   Function: forwardKinematics
//    Summary: Compute position and orientation of the specified link in a
//             specified chain. 
// Parameters: articulation index [0, m_num_articulations-1] and link index,
//             or articulation index == -1 for the reference member.
//    Returns: 4x4 homogeneous transform matrix
//----------------------------------------------------------------------------
bool dmSystem::forwardKinematics(unsigned int link_index,
                                 HomogeneousTransformationMatrix mat)
{
   dmABForKinStruct fk;         // ^{ICS}R_i, ^{ICS}p_i

   // compute the reference member tx matrix - based on Reference System???
   for (int i = 0; i < 3; i++)
   {
      fk.p_ICS[i] = m_p_ICS[i];
      for (int j = 0; j < 3; j++)
      {
         fk.R_ICS[i][j] = m_R_ICS[i][j];
      }
   }

   if (forwardKinematics(link_index, &fk))
   {
      // copy matrix
      for (int i = 0; i < 3; i++)
      {
         mat[i][3] = fk.p_ICS[i];
         mat[3][i] = 0.0;
         for (int j = 0; j < 3; j++)
         {
            mat[i][j] = fk.R_ICS[i][j];
         }
      }
      mat[3][3] = 1.0;

      return true;
   }
   else
   {
      cerr << "dmSystem::forwardKinematics error: invalid link index "
           << link_index << endl;
      return false;
   }
}

// ---------------------------------------------------------------------------
// Function : ABDynamics
// Purpose  : routine to execute AB dynamic simulation
// Inputs   : ref mem and joint current state
// Outputs  : ref nem and joint velocities and accelerations (state
//            derivative). 
// ---------------------------------------------------------------------------
void dmSystem::ABDynamics(Float *qy, Float *qdy)
{
   register unsigned int i, j;

   for (i = 0; i < 6; i++)
   {
      m_beta_star_ref[i] = 0.0;
      for (j = i; j < 6; j++)
      {
         m_I_star_ref[i][j] = 0.0;
      }
   }

   // I. Forward Kinematics
   for (i = 0; i < 3; i++)
   {
      m_ref_val.v[i] = m_ref_val.v[i+3] = 0.0;
      m_ref_val.p_ICS[i] = m_p_ICS[i];
      for (j = 0; j < 3; j++)
      {
         m_ref_val.R_ICS[i][j] = m_R_ICS[j][i];
      }
   }

   ABForwardKinematics(&qy[0], &qy[getNumDOFs()], &m_ref_val);

   // II. Backward Dynamics
   ABBackwardDynamics();

   // III. Forward Accelerations

   //------------------------------------------------------
   // compute biased acceleration for forward recursion.
   // XXX - maybe this should be done when the reference system is set.
   //       however, if the gravity vector should change in the environment,
   //       this object has no way of knowing
   m_accel_ref[0] = 0.0;
   m_accel_ref[1] = 0.0;
   m_accel_ref[2] = 0.0;

   CartesianVector g_ICS, g_ref;
   dmEnvironment::getEnvironment()->getGravity(g_ICS);
   rtxFromICS(g_ICS, g_ref);

   m_accel_ref[3] = -g_ref[XC];
   m_accel_ref[4] = -g_ref[YC];
   m_accel_ref[5] = -g_ref[ZC];
   //------------------------------------------------------

   ABForwardAccelerations(m_accel_ref, &qdy[0], &qdy[getNumDOFs()]);
}
