/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmEnvironment.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class definition for dmEnvironment 
 *****************************************************************************/

#ifndef _DM_ENVIRONMENT_HPP
#define _DM_ENVIRONMENT_HPP

#include <dm.h>
#include <dmObject.hpp>

//======================================================================

/**

The environment class encapsulates all the information the a dynamic simulation
needs for interaction (read forces of contact) between rigid bodies and the
surrounding environment (terrain, friction, gravity, etc...).  In the case of
hydrodynamic simulation (compiled with the -DHYDRODYNAMICS argument), fluid
density and motion are also stored in this class.  The default constructor
initializes an ``empty'' environment with no terrain, zero gravity, and zero
friction coefficients, and when present, zero fluid density and motion.

This class contains a static member variable that will point to the currently
``active'' environment.  It is implemented this way because the dynamic
simulation algorithm needs one environment to query during simulation.  The
current environment is set with a call to the static member function, {\tt
dmEnvironment::setEnvironment}, and passing it a pointer to a previously
instantiated environment object.  Likewise, you can get a pointer to the
current environment with a call to the static member function {\tt
dmEnvironment::getEnvironment}.

{\bf IMPORTANT}: The simulation algorithm will fail with a runtime error if an
environment has not been set in this fashion because various classes directly
reference this object to obtain information about the environment.  Gravity is
defined by a vector (magnitude {\em and} direction) and is set by calling the
{\tt setGravity} function (and can be queried with the {\tt getGravity}).

Currently, only prismatic terrains are supporte (i.e., gridded elevation data,
evenly spaced over a flat plane).  Currently the only way to input terrain data
is to call the {\tt loadTerrainData} with the name of the file containing the
grid spacing and elevation data in the following format:
\begin{verbatim}
    4 5 5.0
    0   0    0    0    0
    0  -2.0 -2.0 -2.0  0
    0  -2.0 -2.0 -2.0  0
    0   0    0    0    0
\end{verbatim}
where the first two numbers define the dimensions of the grid (in numbers of
points along the x and y axes) and the third defines the spacing between the
points in both dimensions.  The rest define the elevation along the z axis.
The {\tt getTerrainFilename} function returns a pointer to the terrain filename
that was loaded.

There are many other (reasonably) self-explanatory set and get member functions
that assign and return spring and damper parameters.  These parameters define
the characteristics of the contact surfaces (slipperiness, rigidity, etc.).
See the programmer's manual (in process) for more details on the current
contact algorithm.  {\em I currently looking for someone to develop the
collision algorithms.} 

In the case of hydrodynamic simulation, there are also member variables that
get and set fluid velocity and acceleration (assumed to be the same over the
entire field), and fluid density.  There is also an {\tt
updateFluidMotionEuler} that I think will update the fluid's velocity based on
the current acceleration.  {\em Not much of a fluid simulation....}

The primary user of this class is the {\tt dmContactModel::computeContactForce}
function which calls the {\tt getGroundElevation} function (in the case of
$z$-axis up prismatic terrains) to help detect collisions of various contact
points with the terrain.  {\em This is a very preliminary class that, like the
{\tt dmContactModel}, could stand a bit of redesign.}  The functions {\tt
getGroundElevation} and {\tt getGroundDepth} both take a position vector and
returns a distance through the terrain, and passes back the normal vector of
the terrain at the point of contact.  Currently only the {\tt
getGroundElevation} has been tested for use with prismatic terrain defined on a
regular grid in the x-y plane with the z-axis pointing up.

Finally two functions, {\tt draw} and {\tt drawInit} are not defined in the
library which the user must write to render the system using whatever 3D API
the user desires.  The framework (no graphics code) for these draw
functions for all classes are provided in {\tt draw.C}.  Examples of these with
OpenGL code is provided with the example that accompanies this
distribution (in {\tt gldraw.C}).

A configuration file reader, {\tt dmLoadFile\_dm} is being supplied in the
dmutils library that can be used to instantiate and intialize contact model
objects.  The lines in the configuration file are expected to be in the
following form:
\begin{verbatim}
    Gravity_Vector                        G_x G_y G_z
    Terrain_Data_Filename                 "filename"
    Ground_Planar_Spring_Constant         k_p
    Ground_Normal_Spring_Constant         k_n
    Ground_Planar_Damper_Constant         b_p
    Ground_Normal_Damper_Constant         b_n
    Ground_Static_Friction_Coeff          u_s
    Ground_Kinetic_Friction_Coeff         u_k
    Fluid_Density                         p
\end{verbatim}

See also {\tt dmContactModel}, {\tt dmLoadFile\_dm}.  */

//======================================================================

class DM_DLL_API dmEnvironment : public dmObject
{
public:
   ///
   dmEnvironment();
   ///
   virtual ~dmEnvironment();

   ///
   static void setEnvironment(dmEnvironment *env) {m_env = env;}
   ///
   static dmEnvironment *getEnvironment() {return m_env;}

   ///
   void loadTerrainData(char *filename);
   ///
   Float **getTerrainData(int &xdim, int &ydim, Float &spacing)
      {
         xdim = x_dim; ydim = y_dim; spacing = grid_resolution; return depth;
      }
   ///
   const char *getTerrainFilename() const {return m_terrain_filename;}

// accessor functions:
   ///
   inline void setGravity(CartesianVector a_g);
   ///
   inline void getGravity(CartesianVector a_g) const;

   ///
   inline void setGroundPlanarSpringConstant(Float k);
   ///
   inline void setGroundNormalSpringConstant(Float k);
   ///
   inline void setGroundPlanarDamperConstant(Float k);
   ///
   inline void setGroundNormalDamperConstant(Float k);
   ///
   inline void setFrictionCoeffs(Float u_s, Float u_k);

   ///
   inline Float getGroundPlanarSpringConstant() const;
   ///
   inline Float getGroundNormalSpringConstant() const;
   ///
   inline Float getGroundPlanarDamperConstant() const;
   ///
   inline Float getGroundNormalDamperConstant() const;
   ///
   inline Float getGroundStaticFrictionCoeff() const;
   ///
   inline Float getGroundKineticFrictionCoeff() const;

#ifdef HYDRODYNAMICS
   ///
   inline Float getFluidDensity() const;
   ///
   inline void  setFluidDensity(Float d);
   ///
   inline void getFluidVel(CartesianVector v) const;
   ///
   inline void setFluidVel(CartesianVector v);
   ///
   inline void getFluidAcc(CartesianVector a) const;
   ///
   inline void setFluidAcc(CartesianVector a);

   ///
   void updateFluidMotionEuler(Float idt, CartesianVector position);
#endif

   ///
   Float getGroundDepth(CartesianVector contact_pos,
                        CartesianVector ground_normal);

   ///
   Float getGroundElevation(CartesianVector contact_pos,
                            CartesianVector ground_normal);


// rendering functions:
   ///
   void drawInit();
   ///
   void draw();

private:
   // not implemented
   dmEnvironment(const dmEnvironment &);
   dmEnvironment &operator=(const dmEnvironment &);

private:
   static dmEnvironment *m_env;  // "there can be only one"

   CartesianVector m_gravity; // gravitational acceleration vector ("down")
                              // e.g. [0,0,-9.81] m/s^2 avg at Earth's surface

   // terrain characteristics for gridded data specification
   int x_dim, y_dim;            // dimension of terrain grid data
   Float grid_resolution;       // distance b/w grid points
   Float **depth;               // 2D array of depth data.

   char *m_terrain_filename;
   int m_terrain_model_index;

   // ground contact force characteristics
   Float ground_planar_spring_constant;
   Float ground_normal_spring_constant;

   Float ground_planar_damper_constant;
   Float ground_normal_damper_constant;

   Float ground_static_friction_coeff;
   Float ground_kinetic_friction_coeff;

#ifdef HYDRODYNAMICS
   Float fluid_density;         // e.g. 1020.0 kg/m^3 avg sea water.

   CartesianVector fluid_vel;
   CartesianVector fluid_acc;
#endif
};

// Inlined functions:

inline void dmEnvironment::setGravity(CartesianVector a_g)
{
   m_gravity[XC] = a_g[XC];
   m_gravity[YC] = a_g[YC];
   m_gravity[ZC] = a_g[ZC];
}

inline void dmEnvironment::getGravity(CartesianVector a_g) const
{
   a_g[XC] = m_gravity[XC];
   a_g[YC] = m_gravity[YC];
   a_g[ZC] = m_gravity[ZC];
}


inline void dmEnvironment::setGroundPlanarSpringConstant(Float k)
{
   ground_planar_spring_constant = k;
}

inline Float dmEnvironment::getGroundPlanarSpringConstant() const
{
   return ground_planar_spring_constant;
}


inline void dmEnvironment::setGroundNormalSpringConstant(Float k)
{
   ground_normal_spring_constant = k;
}

inline Float dmEnvironment::getGroundNormalSpringConstant() const
{
   return ground_normal_spring_constant;
}


inline void dmEnvironment::setGroundPlanarDamperConstant(Float k)
{
   ground_planar_damper_constant = k;
}

inline Float dmEnvironment::getGroundPlanarDamperConstant() const
{
   return ground_planar_damper_constant;
}


inline void dmEnvironment::setGroundNormalDamperConstant(Float k)
{
   ground_normal_damper_constant = k;

}

inline Float dmEnvironment::getGroundNormalDamperConstant() const
{
   return ground_normal_damper_constant;
}


inline void dmEnvironment::setFrictionCoeffs(Float u_s, Float u_k)
{
   ground_static_friction_coeff = u_s;
   ground_kinetic_friction_coeff = u_k;

   if (ground_kinetic_friction_coeff > ground_static_friction_coeff)
   {
      cerr << "dmEnvironment error: kinetic > static friction coefficient.\n";
   }
}

inline Float dmEnvironment::getGroundStaticFrictionCoeff() const
{
   return ground_static_friction_coeff;
}


inline Float dmEnvironment::getGroundKineticFrictionCoeff() const
{
   return ground_kinetic_friction_coeff;
}


#ifdef HYDRODYNAMICS
inline void dmEnvironment::setFluidDensity(Float d)
{
   fluid_density = d;
}

inline Float dmEnvironment::getFluidDensity() const
{
   return fluid_density;
}


inline void dmEnvironment::setFluidVel(CartesianVector v)
{
   for (int i=0; i<3; i++) fluid_vel[i] = v[i];
}

inline void dmEnvironment::getFluidVel(CartesianVector v) const
{
   for (int i=0; i<3; i++) v[i] = fluid_vel[i];
}


inline void dmEnvironment::setFluidAcc(CartesianVector a)
{
   for (int i=0; i<3; i++) fluid_acc[i] = a[i];
}

inline void dmEnvironment::getFluidAcc(CartesianVector a) const
{
   for (int i=0; i<3; i++) a[i] = fluid_acc[i];
}
#endif

#endif
