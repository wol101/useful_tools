/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmRevoluteLink.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0
 *  Summary: Class definitions for links with revolute joints
 *****************************************************************************/

#ifndef _DM_REVOLUTE_LINK_HPP
#define _DM_REVOLUTE_LINK_HPP

#include <dm.h>
#include <dmMDHLink.hpp>

//============================================================================
/**

This class is one of the two concrete {\tt dmLink} classes derived from the
{\tt dmMDHLink} class.  It implements the dynamics specific to a revolute
(rotational) one degree of freedom joint.

{\em Not reference manual material:} The primary purpose of this class is to
implement the {\tt scongToInboardIrefl} member function, a very efficient
congruence transformation of the Articulated-Body inertia matrix that is
transformed across the revolute joint.  In this case, the third row and column
of the matrix are zero and taking this into account results in significant
computation savings (for all the gorey details, please read my dissertation or
Robotics and Automation Journal article).  The {\tt
dmMDHLink::ABBackwardDynamics[N]} functions call this function in the course of
computing the dynamics.  It should probably be a private/protected member
function, but since it does not modify any member variables there is no harm in
leaving it public.

See also: {\tt dmMDHLink}, {\tt dmLoadFile\_dm}.
 */

class DM_DLL_API dmRevoluteLink : public dmMDHLink
{
public:
   ///
   dmRevoluteLink();
   ///
   virtual ~dmRevoluteLink();

   ///
   void scongtxToInboardIrefl(SpatialTensor N, SpatialTensor I) const;

// Rendering functions:
   ///
   void draw();

private:
   // not implemented
   dmRevoluteLink(const dmRevoluteLink &);
   dmRevoluteLink &operator=(const dmRevoluteLink &);

   void computeZeta(SpatialVector omega_inboard,
                    SpatialVector omega_curr,
                    SpatialVector zeta);

   void setJointPos(Float joint_pos);
   inline Float getJointPos() const { return m_thetaMDH; }
};

#endif
