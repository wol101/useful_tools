/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmArticulation.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: Class definition for general articulated structures
 *****************************************************************************/

#ifndef _DM_ARTICULATION_HPP
#define _DM_ARTICULATION_HPP

#include <dm.h>
#include <dmLink.hpp>
#include <dmSystem.hpp>

#include <vector>

//============================================================================
/**

The {\tt dmArticulation} class would be better named the {\tt dmTreeStructure}
class.  It is a subclass of the {\tt dmSystem} class that implements the
functionality need to model links organized in a tree topology.  {\em Soon a
subclass of {\tt dmArticulation} will allow extension of the package to
closed-chain structures.}  This class contains a database of links and the
predecessor/successor relationships between links that define the tree
topology.  As such, the first link and any other link added to the articulation
using the {\tt addLink} function with the second argument set to NULL are
considered that root of the tree.  Then, as additional links are added to the
articulation, a pointer to a parent link (already added to the articulation) is
used to specify its location in the tree.  As a result, each link in a tree has
only one parent.  The only exceptions are the root links that are defined
relative to the {\tt dmSystem}'s inertial reference coordinate system.

The default constructor returns an empty articulation (that is, with no
links).  As links are added to the articulation, internal variables are
allocated that will be used to perform the dynamic computations.  When the
destructor is called these internal variables are freed but any links that
have been added to the articulation are not.

The {\tt addLink} function is called to add a link to the tree structure that
is maintained by the {\tt dmArticulation} objects.  The first parameter is a
pointer to a previously instantiated link object that is to be added, and the
second parameter is a pointer to a link that has already been added to the
articulation and will be the "parent" to the new link and placed in the
database accordingly.  Note that the first link added has no parent so the {\tt
parent} parameter is set to {\tt NULL}.  If the operation is successful, this
function returns {\tt true}; otherwise it will return {\tt false} for any one
of a number of reasons (parent not found, variable allocation failure, etc.)

The articulation can be queried for the number of links in the tree by calling
{\tt getNumLinks}.  A pointer to a specific link can be obtained by calling
{\tt getLink} with the appropriate index.  The index corresponds to the order
in which the links were added to the tree: 0 for the first link,
1 for the second, etc.  If the index is out of range, {\tt getLink} returns
{\tt NULL}.  The inverse function, {\tt getLinkIndex} takes a {\tt dmLink}
pointer and returns its corresponding index, or {\tt -1} if the link is not
contained in the tree or the pointer is {\tt NULL}.

{\em Do I need to add tree traversal functions like {\tt getParent,
getNumChild}, etc...(either here or in dmLink)?}

Three functions, {\tt setJointInput}, {\tt setState}, and {\tt getState}, are
used to set and query joint states and inputs for the links in the entire
tree.  The first, {\tt setJointInput}, sets the joint inputs (either torques,
forces, or motor voltages) for all the links in the articulation.  Its {\tt
joint\_input} argument is a packed (one-dimensional) array with length equal
to the total number of DOFs in the articulation.  The elements of this array
correspond to the DOFs of each link in the order they were added to the
articulation. {\tt setState} sets the state of the DOFs in the articulation.
The two arguments are both packed arrays (like {\tt joint\_input}) containing
the joint positions and velocities of the links.  The reverse operation, {\tt
getState}, fills packed arrays with the joint positions velocities.  A
convenience function, {\tt getNumDOFs}, returns the total number of degrees
of freedom in the articulation and can be used to determine the appropriate
size of the above arrays.

The {\tt forwardKinematics} function composes the homogeneous transformation
matrix to the link indicated by the first parameter, {\tt link\_index}.  The
second parameter, {\tt fk}, is a pointer to a {\tt dmABForKinStruct} (from 
{\tt dm.h}):
\begin{verbatim}
   struct dmABForKinStruct
   {
      RotationMatrix  R_ICS;     // orientation of links wrt ICS - ^{ICS}R_{i}
      CartesianVector p_ICS;     // position of links wrt ICS - ^{ICS}p_{i}
      SpatialVector   v;         // velocity of link wrt to i.
        ...
   };
\end{verbatim}
Upon calling this function in normal use, {\tt R\_ICS} and {\tt p\_ICS} will
contain the transformation from the inertial coordinate system to the reference
system (defined in {\tt dmSystem}) relative to which this articulation is
defined.  Normally this function is called by
{\tt dmSystem::forwardKinematics()} after filling the {\tt fk} parameter with
the proper values.  Upon exit this function will fill {\tt R\_ICS} and {\tt
p\_ICS} with the resulting transformation information and return {\tt true}.
If the {\tt link\_index} is out of range, this function returns {\tt false}.
{\em Should I make this function private and {\tt dmSystem}'s a friend?}

The three functions, {\tt ABForwardKinematics}, {\tt ABBackwardDynamics}, and
{\tt ABForwardAccelerations}, comprise the implementation of the
Articulated-Body (AB) Simulation alogrithm recursions are hidden from the user
and are only be called by {\tt dmSystem::ABDynamics}. 
However, during the Forward Kinematics traversal, {\tt dmABForKinStruct}s are
computed for each link which can be accessed by calling the {\tt
getForKinStruct} function with the index of the desired link.  This functions
returns a pointer to the requested struct, or NULL if the index is out of
range. 

See also {\tt dmSystem, dmLink}.

*/

//============================================================================

class DM_DLL_API dmArticulation : public dmSystem
{
public:
   ///
   dmArticulation();
   ///
   virtual ~dmArticulation();

   ///
   bool addLink(dmLink *new_link, dmLink *parent_link);
   ///
   unsigned int getNumLinks() const { return m_link_list.size(); }
   ///
   dmLink *getLink(unsigned int index) const;
   ///
   int getLinkIndex(dmLink *link) const;

   ///
   unsigned int getNumDOFs() const { return m_num_state_vars; }

   ///
   void setJointInput(Float joint_input[]);
   ///
   void setState(Float q[], Float qd[]);
   ///
   void getState(Float q[], Float qd[]) const;

   ///
   bool forwardKinematics(unsigned int link_index, dmABForKinStruct *fk);

   ///
   const dmABForKinStruct *getForKinStruct(unsigned int link_index) const;

// rendering function:
   ///
   void draw();

protected:
   // not implemented
   dmArticulation(const dmArticulation &);
   dmArticulation &operator=(const dmArticulation &);

// AB algorithm functions:
   void ABForwardKinematics(Float q[], Float qd[], dmABForKinStruct *ref_val);
   void ABBackwardDynamics();
   void ABForwardAccelerations(SpatialVector a_ref, Float qd[], Float qdd[]);

   struct LinkInfoStruct
   {
      dmLink *link;

      LinkInfoStruct *parent;
      vector<LinkInfoStruct*> child_list;

      dmABForKinStruct link_val;

      // AB algorithm temporaries
      SpatialVector accel;
      SpatialVector f_star;
      SpatialTensor I_refl;
   };

   void drawTraversal(LinkInfoStruct *node);

protected:
   vector<LinkInfoStruct*> m_link_list;
   unsigned int m_num_state_vars;
};

#endif
