/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmMobileBaseLink.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary: Class definition for a 6dof link (used to be the
 *           dmDynamicRefMember class.
 *****************************************************************************/

#ifndef _DM_MOBILE_BASE_LINK_HPP
#define _DM_MOBILE_BASE_LINK_HPP

#include <dm.h>
#include <dmRigidBody.hpp>

//======================================================================

/**

The {\tt dmMobileBaseLinks} objects are links with six degrees of freedom, and
hence, the class is derived from the {\tt dmRigidBody} (for the dynamic
parameters) and, through that, the {\tt dmLink} base class (required by {\tt
dmArticulation} for Articulated-Body simulation functions.  The default
constructor instantiates a generic mobile base with some valid inertial
parameters and zero state variables, but subsequent calls to this and the {\tt
dmRigidBody} member functions are needed to set the desired values.

Nearly all of the remainder of the functions are described in the {\tt
dmLink} reference pages and are implemented in this class for the specific
case of links with a full 6 DOF.

See also: {\tt dmRigidBody}, {\tt dmLink}, {\tt dmLoadFile\_dm} */

class DM_DLL_API dmMobileBaseLink : public dmRigidBody
{
public:
   enum {NUM_VARS = 7};

public:
   ///
   dmMobileBaseLink();
   ///
   virtual ~dmMobileBaseLink();

   ///
   virtual int getNumDOFs() const { return NUM_VARS; }
   ///
   virtual void setState(Float q[], Float qd[]);
   ///
   virtual void getState(Float q[], Float qd[]) const;
   ///
   virtual void getPose(RotationMatrix R, CartesianVector p) const;

   void setJointInput(Float []) {};

   ///
   void getDeriv(Float rdy[13]);

// Link-to-Link transformation functions:
   /// *
   void rtxToInboard(CartesianVector curr, CartesianVector prev) const;
   /// *
   void rtxFromInboard(CartesianVector prev, CartesianVector curr) const;
   /// not implemented
   void stxToInboard(SpatialVector curr, SpatialVector prev) const;
   /// not implemented
   void stxFromInboard(SpatialVector prev, SpatialVector curr) const;
   /// not implemented
   void rcongtxToInboardSym(CartesianTensor Curr, CartesianTensor Prev) const;
   /// not implemented
   void rcongtxToInboardGen(CartesianTensor Curr, CartesianTensor Prev) const;
   /// not implemented
   void scongtxToInboardIrefl(SpatialTensor N, SpatialTensor I) const;

// Articulated-Body (AB) algorithm functions:
   ///
   virtual void ABForwardKinematics(Float q[],
                                    Float qd[],
                                    dmABForKinStruct *link_val_inboard,
                                    dmABForKinStruct *link_val_curr);

   ///
   virtual void ABBackwardDynamics(dmABForKinStruct *link_val_curr,
                                   SpatialVector f_star_curr,
                                   SpatialTensor N_refl_curr,
                                   SpatialVector f_star_inboard,
                                   SpatialTensor N_refl_inboard);
   ///
   virtual void ABBackwardDynamicsN(dmABForKinStruct *link_val_curr,
                                    SpatialVector f_star_inboard,
                                    SpatialTensor N_refl_inboard);

   ///
   virtual void ABForwardAccelerations(SpatialVector a_inboard,
                                       SpatialVector a_curr,
                                       Float qd[],
                                       Float qdd[]);

// rendering functions:
   ///
   void draw();

private:
   // not implemented
   dmMobileBaseLink(const dmMobileBaseLink &);
   dmMobileBaseLink &operator=(const dmMobileBaseLink &);

   void initABVars() {};
   inline void setJointPos(Quaternion q, CartesianVector p);

private:
   Quaternion      m_quat;     // orientation quaternion
   RotationMatrix  m_R;        //     ^b{\bf R}_ICS
                               // position stored in dmLink::m_p

   SpatialVector m_vel;        // velocity and accel wrt ICS.
   SpatialVector m_acc;
};

//----------------------------------------------------------------------------
//    Summary: 3D rotational transformation from ref mem CS to ICS
// Parameters: p_ref - 3-vector expressed in ref mem's CS
//    Returns: p_ICS - 3-vector expressed in the ICS
//----------------------------------------------------------------------------
inline void dmMobileBaseLink::rtxToInboard(CartesianVector p_ref,
                                           CartesianVector p_ICS) const
{
   p_ICS[0] = m_R[0][0]*p_ref[0] + m_R[1][0]*p_ref[1] + m_R[2][0]*p_ref[2];
   p_ICS[1] = m_R[0][1]*p_ref[0] + m_R[1][1]*p_ref[1] + m_R[2][1]*p_ref[2];
   p_ICS[2] = m_R[0][2]*p_ref[0] + m_R[1][2]*p_ref[1] + m_R[2][2]*p_ref[2];
}

//----------------------------------------------------------------------------
//    Summary: 3D rotational transformation from ICS to ref mem CS
// Parameters: p_ICS - 3-vector expressed in the ICS
//    Returns: p_ref - 3-vector expressed in ref mem's CS
//----------------------------------------------------------------------------
inline void dmMobileBaseLink::rtxFromInboard(CartesianVector p_ICS,
                                             CartesianVector p_ref) const
{
   p_ref[0] = m_R[0][0]*p_ICS[0] + m_R[0][1]*p_ICS[1] + m_R[0][2]*p_ICS[2];
   p_ref[1] = m_R[1][0]*p_ICS[0] + m_R[1][1]*p_ICS[1] + m_R[1][2]*p_ICS[2];
   p_ref[2] = m_R[2][0]*p_ICS[0] + m_R[2][1]*p_ICS[1] + m_R[2][2]*p_ICS[2];
}

#endif
