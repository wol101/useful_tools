/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmIntegrator.hpp
 *   Author: Scott McMillan
 *  Project: DynaMechs 3.0 
 *  Summary:  Abstract base class for numerical integrators.
 *****************************************************************************/

#ifndef _DM_INTEGRATOR_HPP
#define _DM_INTEGRATOR_HPP

#include <dm.h>
#include <dmObject.hpp>
#include <dmSystem.hpp>

//============================================================================

/**

This class is under major construction.

This is the abstract base class for numerical integrators that will be used in
conjunction with a {\tt dmSystem} object to perform the dynamic simulation.
After construction of a derived class, a system object must be assigned to the
integrator object with a call to the {\tt setSystem} function.  A pointer to
currently assigned system can be obtained with a call to the {\tt getSystem}
function.  Currently, a new system cannot be properly assigned to an integrator
after the initial assignment.

Immediately after construction of this class, it is not setup to numerically
integrate anything and a call to {\tt isReadyToSim} returns FALSE.  After a
system has been assigned and internal variables have been successfully
allocated (based on the number of degrees of freedom in the system), this
function will return TRUE.

The system is simulated by calling the {\tt simulate} function which is a pure
virtual function implemented in the derived integrator classes (see {\tt
dmIntegEuler, dmIntegRK4}, etc.).  The {\tt idt} parameter, indicates how much
time should be simulated in seconds, and on return will contain the amount of
time that was actually simulated.

 */

//======================================================================

class DM_DLL_API dmIntegrator : public dmObject
{
public:
   ///
   dmIntegrator();
   ///
   virtual ~dmIntegrator();

   ///
   void setSystem(dmSystem *system);
   ///
   dmSystem *getSystem() { return m_system; }

   ///
   int isReadyToSim() const { return m_ready_to_sim; }

   ///
   virtual void simulate(Float &idt) = 0;

protected:
   // not implemented
   dmIntegrator(const dmIntegrator &);
   dmIntegrator &operator=(const dmIntegrator &);

   virtual bool allocateStateVariables() = 0;

protected:
   dmSystem *m_system;
   bool m_ready_to_sim;  // true if all sim vars allocated properly
   int m_num_state_vars;
};

#endif
