/*****************************************************************************
 * Copyright 1996, Scott McMillan
 *****************************************************************************
 *     File: dm.h
 *   Author: Scott McMillan
 *  Created: ?/?/1996
 *  Summary: All typedefs, constants and functions needed for DynaMechs
 *****************************************************************************/

#ifndef _DM_H
#define _DM_H

#if defined(WIN32)
// The next define will come from the makefile for archive objects.
#ifdef dm_DLL_FILE
#define DM_DLL_API __declspec(dllexport)
#else
#define DM_DLL_API __declspec(dllimport)
#endif
#else
#define DM_DLL_API
#endif

#if defined(WIN32)
#include <windows.h>
#endif

// a bunch of hacks to select standard conforming iostream stuff if available
// on the platform

#if defined(WIN32) || (defined(sgi) && defined(_STANDARD_C_PLUS_PLUS)) || (defined(__GNUC__) && (__GNUC__>=2) && (__GNUC_MINOR__>=91))
#include <iostream>
#include <iomanip>
#include <fstream>
#else
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#endif

#include <math.h>
#include <stdlib.h>
#include <string.h>

#ifndef NULL
#define NULL 0
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

const float RADTODEG = (float)(180.0/M_PI);    // M_PI is defined in math.h
const float DEGTORAD = (float)(M_PI/180.0);

const int FILENAME_SIZE = 120;

enum { XC = 0, YC = 1, ZC = 2, ANGLE = 3 };
enum { PHI = 0, THETA = 1, PSI = 2};

#ifdef DM_DOUBLE_PRECISION
typedef double Float;   // changing this one line between float and double
                        // toggles the entire lib b/w single/double precision 
#else
typedef float Float;
#endif

typedef Float SpatialTensor[6][6];
typedef Float SpatialVector[6];
typedef Float CartesianTensor[3][3];
typedef Float CartesianVector[3];
typedef Float EulerAngles[3];
typedef Float Quaternion[4];
typedef Float RotationMatrix[3][3];
typedef Float HomogeneousTransformationMatrix[4][4];

//----------------------------------------------------------------------------
// Summary: struct containing variables used in ABForwardKinematics for a 
//          single link.
//----------------------------------------------------------------------------
struct dmABForKinStruct
{
   RotationMatrix  R_ICS;     // pose of links wrt ICS - ^{ICS}R_{i}
   CartesianVector p_ICS;     // pos. of links wrt ICS - ^{ICS}p_{i}
   SpatialVector   v;         // velocity of link wrt to i.

#ifdef HYDRODYNAMICS
   CartesianVector v_f;       // velocity of fluid wrt to i.
   CartesianVector a_fg;      // a_f - a_g wrt to i.
#endif
};

// Use the std namespace. To do this we must first guarantee that it exists.
#if defined(__sgi) || defined(__WIN32_) || defined(WIN32)
namespace std {}
using namespace std;
#endif

//----------------------------------------------------------------------------
inline void normalizeQuat(Float quat[4])
{
   Float len = sqrt(quat[0]*quat[0] +
                    quat[1]*quat[1] +
                    quat[2]*quat[2] +
                    quat[3]*quat[3]);
   //cerr << len << endl;
   if (len > 0.000001)
   {
      quat[0] /= len;
      quat[1] /= len;
      quat[2] /= len;
      quat[3] /= len;
   }
   else
   {
      // This is an error condition
      cerr << "Warning: normalizing zero quaternion: [" << quat[0] << ", "
           << quat[1] << ", " << quat[2] << ", " << quat[3] << "]" << endl;
      quat[0] = quat[1] = quat[2] = 0.0;
      quat[3] = 1.0;
   }
}

// ---------------------------------------------------------------------

inline void buildRotMat(Quaternion quat, RotationMatrix R)
{
   // set the transformation matrix
   static Float q1,q2,q3, q1q1,q2q2,q3q3, q1q2,q1q3,q2q3, q1q4,q2q4,q3q4;

   q1 = 2*quat[0];
   q2 = 2*quat[1];
   q3 = 2*quat[2];

   q1q1 = q1*quat[0];
   q2q2 = q2*quat[1];
   q3q3 = q3*quat[2];

   q1q2 = q1*quat[1];
   q1q3 = q1*quat[2];
   q2q3 = q2*quat[2];

   q1q4 = q1*quat[3];
   q2q4 = q2*quat[3];
   q3q4 = q3*quat[3];

   R[0][0] = 1.0 - (q3q3 + q2q2);
   R[1][0] = q1q2 - q3q4;
   R[2][0] = q1q3 + q2q4;

   R[0][1] = q1q2 + q3q4;
   R[1][1] = 1.0 - (q3q3 + q1q1);
   R[2][1] = q2q3 - q1q4;

   R[0][2] = q1q3 - q2q4;
   R[1][2] = q2q3 + q1q4;
   R[2][2] = 1.0 - (q2q2 + q1q1);
}

// ---------------------------------------------------------------------
// Function : crossproduct
// Purpose  : perform the Cartesian vector crossproduct a x b = c 
// Inputs   : a, b
// Outputs  : c
// ---------------------------------------------------------------------
inline void crossproduct(const Float *a, const Float *b, Float *c)
{
   c[0] = a[1]*b[2] - a[2]*b[1];
   c[1] = a[2]*b[0] - a[0]*b[2];
   c[2] = a[0]*b[1] - a[1]*b[0];
}

// ---------------------------------------------------------------------
inline void cross(float a[3], float b[3], float c[3])
{
   c[0] = a[1]*b[2] - a[2]*b[1];
   c[1] = a[2]*b[0] - a[0]*b[2];
   c[2] = a[0]*b[1] - a[1]*b[0];
}

//----------------------------------------------------------------------------
inline float normalize(float v[3])
{
    float norm = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);

    if (norm > 0.0)
    {
       v[0] /= norm;
       v[1] /= norm;
       v[2] /= norm;
    }

    return norm;
}

//----------------------------------------------------------------------------
inline void compute_face_normal(float v0[3], float v1[3], float v2[3],
                                float normal[3])
{
    float a[3], b[3];
    register int i;

    for (i=0; i<3; i++)
    {
        a[i] = v1[i] - v0[i];
        b[i] = v2[i] - v0[i];
    }

    cross(a, b, normal);
    normalize(normal);

}

#endif
