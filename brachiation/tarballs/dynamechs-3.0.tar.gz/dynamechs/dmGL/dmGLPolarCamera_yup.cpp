/*****************************************************************************
 * Copyright 2000, Scott McMillan
 *****************************************************************************
 *     File: dmGLPolarCamera_yup.cpp
 *   Author: Scott McMillan
 *  Created: 1998/05/01
 *  Summary: 
 *****************************************************************************/

#include <dmGL.h>
#include <dmGLPolarCamera.hpp>
#include <dmGLPolarCamera_yup.hpp>

//----------------------------------------------------------------------------
//    Summary: 
// Parameters: 
//    Returns: 
//----------------------------------------------------------------------------
dmGLPolarCamera_yup::dmGLPolarCamera_yup() :
      dmGLPolarCamera()
{
}

//----------------------------------------------------------------------------
//    Summary: 
// Parameters: 
//    Returns: 
//----------------------------------------------------------------------------
void dmGLPolarCamera_yup::spinScene(int delta[2], int button)
{
   if (button & MOUSE_LEFT_DOWN)
   {
      // mouse x position controls azimuth
      // mouse y position controls elevation
      updateAzimuth(-delta[0]*0.5);
      updateElevation(-delta[1]*0.5);
   }

   if (button & MOUSE_MIDDLE_DOWN)
   {
      static float delta_pos[3];

      delta_pos[0] = -m_trans_scale*delta[0];
      delta_pos[1] =  m_trans_scale*delta[1];
      //delta_pos[2] = 0.0;

      m_pos_coi[0] += delta_pos[0]*m_cos_az
         + delta_pos[1]*m_sin_az*m_sin_el;
      // + delta_pos[2]*m_sin_az*m_cos_el;

      m_pos_coi[1] += delta_pos[1]*m_cos_el;
      // - delta_pos[2]*m_sin_el;

      m_pos_coi[2] +=-delta_pos[0]*m_sin_az
         + delta_pos[1]*m_cos_az*m_sin_el;
      // + delta_pos[2]*m_cos_az*m_cos_el;
   }

   if (button & MOUSE_RIGHT_DOWN)
   {
      updateRadius(-m_trans_scale*delta[1]);
   }
}

//----------------------------------------------------------------------------
//   Function: 
//    Summary: 
// Parameters: 
//    Returns: 
//----------------------------------------------------------------------------
void dmGLPolarCamera_yup::applyView()
{
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   m_look_from[0] = m_pos_coi[0] + m_radius*m_sin_az*m_cos_el;
   m_look_from[1] = m_pos_coi[1] - m_radius*m_sin_el;
   m_look_from[2] = m_pos_coi[2] + m_radius*m_cos_az*m_cos_el;

   m_up[0] = m_sin_az*m_sin_el;
   m_up[1] = m_cos_el;
   m_up[2] = m_cos_az*m_sin_el;

   gluLookAt(m_look_from[0], m_look_from[1], m_look_from[2],
             m_pos_coi[0], m_pos_coi[1], m_pos_coi[2],
             m_up[0], m_up[1], m_up[2]);

}
