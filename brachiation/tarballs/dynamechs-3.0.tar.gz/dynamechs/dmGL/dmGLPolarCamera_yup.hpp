/*****************************************************************************
 * Copyright 2000, Scott McMillan
 *****************************************************************************
 *     File: dmGLPolarCamera_yup.hpp
 *   Author: Scott McMillan
 *  Created: 1998/05/01
 *  Summary: 
 *****************************************************************************/

#ifndef _DMGL_POLAR_CAMERA_YUP_HPP
#define _DMGL_POLAR_CAMERA_YUP_HPP

#include <dmGL.h>
#include <dmGLMouse.hpp>
#include <dmGLPolarCamera.hpp>

class DMGL_DLL_API dmGLPolarCamera_yup : public dmGLPolarCamera
{
public:
   dmGLPolarCamera_yup();
   virtual ~dmGLPolarCamera_yup() {};

   virtual void spinScene(int delta[2], int button_flags);
   virtual void applyView();

private:
   dmGLPolarCamera_yup(const dmGLPolarCamera_yup &);
};

#endif
