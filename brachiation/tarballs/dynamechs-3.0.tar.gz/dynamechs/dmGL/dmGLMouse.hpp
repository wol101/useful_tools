/*****************************************************************************
 * Copyright 2000, Scott McMillan
 *****************************************************************************
 *     File: dmGLMouse.hpp
 *   Author: Scott McMillan
 *  Created: 22 March 1997
 *  Summary: 
 *****************************************************************************/

#ifndef _DMGL_MOUSE_HPP
#define _DMGL_MOUSE_HPP

#include <dmGL.h>

//----------------------------------------------------------------------------

enum {MOUSE_LEFT_DOWN   = 0x01,
      MOUSE_MIDDLE_DOWN = 0x02,
      MOUSE_RIGHT_DOWN  = 0x04};

//----------------------------------------------------------------------------

struct DMGL_DLL_API dmGLMouse
{
   int window;          // window for which this mouse class has been init'ed
   int win_size_x;
   int win_size_y;
                             
   int in_window_flag;  // TRUE if mouse is in window
   int button_flags;    // bitmasks 4,2,1 for right,middle,left buttons
   int xwin, ywin;      // position within window
   float xchan, ychan;  // normalized window position

   static dmGLMouse *dmInitGLMouse();
};

#endif
