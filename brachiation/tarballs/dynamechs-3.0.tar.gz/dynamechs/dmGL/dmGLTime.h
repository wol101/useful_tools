/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: dmGLTime.h
 *   Author: Scott McMillan
 *  Created: 30 June 1999
 *  Summary: Cross platform timing for test programs
 *****************************************************************************/

#ifndef __DMGL_TIME_H
#define __DMGL_TIME_H

#include <dmGL.h>

//----------------------------------------------------------------------------
#if defined(WIN32)
#   include <sys/timeb.h>
#   include <time.h>

struct dmGLTimespec
{
    time_t   tv_sec;     // seconds
    long     tv_nsec;    // and nanoseconds
};

#else
#  if defined(_POSIX_C_SOURCE) & defined(USE_POSIX)
#   include <time.h>
#  else
#   include <sys/time.h>
#  endif
typedef timespec dmGLTimespec;
#endif

inline void dmglGetSysTime(dmGLTimespec *ts)
{
#if defined(WIN32)
    struct _timeb timebuffer;
    _ftime(&timebuffer);

    ts->tv_sec = timebuffer.time;
    ts->tv_nsec = timebuffer.millitm*1000000;

#elif defined(_POSIX_C_SOURCE) & defined(USE_POSIX)
    if (clock_gettime(CLOCK_REALTIME, ts) != 0)
    {
        throw ts;
    }
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    ts->tv_sec = tv.tv_sec;
    ts->tv_nsec = 1000*tv.tv_usec;
#endif
}

#endif
