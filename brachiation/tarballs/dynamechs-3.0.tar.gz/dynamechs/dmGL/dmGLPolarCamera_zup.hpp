/*****************************************************************************
 * Copyright 2000, Scott McMillan
 *****************************************************************************
 *     File: dmGLPolarCamera_zup.hpp
 *   Author: Scott McMillan
 *  Created: 1998/05/01
 *  Summary: 
 *****************************************************************************/

#ifndef _DMGL_POLAR_CAMERA_ZUP_HPP
#define _DMGL_POLAR_CAMERA_ZUP_HPP

#include <dmGL.h>
#include <dmGLMouse.hpp>
#include <dmGLPolarCamera.hpp>

class DMGL_DLL_API dmGLPolarCamera_zup : public dmGLPolarCamera
{
public:
   dmGLPolarCamera_zup();
   virtual ~dmGLPolarCamera_zup() {};

   virtual void spinScene(int delta[2], int button_flags);
   virtual void applyView();

private:
   dmGLPolarCamera_zup(const dmGLPolarCamera_zup &);
};

#endif
