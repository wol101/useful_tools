#!/usr/bin/perl


sub parseOldDepends {
  my $inFile = shift(@_);
  my $outFile = shift(@_);
  my $dirtyOut = shift(@_);
  my @dirtyIn = split(" ", $dirtyOut);

  if (open(INFILE, $inFile)) {
  LINE: foreach (<INFILE>) {
      for ($ii = 0; $ii <= $#dirtyIn; $ii++) {
	if (m/.*$dirtyIn[$ii].*/) {
	  m/ (.*): (.*)/;
	  ($first, $second) = split(/ /, $2, 2);
	  if (!grep(/$first/, $dirtyOut)) {
	    $dirtyOut .= " " . $first;
	  }
	  next LINE;
	}
      }
      if ($_ ne "\n") {
	print OUTFILE $_;
      }
    }
    
    close(INFILE);
  }
  
  return $dirtyOut;
}

sub collapse {
  my $filler = shift(@_);
  my $currline = "";
  my @inlines = split("\n", shift(@_));
  foreach (@inlines) {
    if (m/.*\\$/o) {
      chop; chop;
      $currline .= $_;
    } else {
      $currline .= $_;
      ($first, $second) = split(/:/, $currline, 2);
      chomp($second);
      $second =~ s! /[^ ]*!!og;
      $second =~ s! [a-zA-Z]:[^ ]*!!og;
      $second =~ s!\\!/!og;
      $lines{$first} .= $second;
      $currline = "";
    }
  }

  foreach (keys %lines) {
    chomp($lines{$_});
    if ($lines{$_} ne "") {
      print OUTFILE $filler . "$_:$lines{$_}\n";
    }
  }
}


##############################################################################

$inFile = shift(@ARGV);
$outFile = $inFile . ".tmp";

unlink $outFile;
open(OUTFILE, ">$outFile") 
  || die "$0 unable to open output file: $outFile";

#print "ARGV= @ARGV \n";

($dirtyIn, $allArgs) = split(" -- ", join(" ",@ARGV));

#print "dirtyIn= $dirtyIn \n";

foreach (split(" ", $allArgs)) {
  if (/^-D.*/) {
    $cxxArgs .= " " . $_;
  }
  if (/^-I.*/) {
    $cxxArgs .= " " . $_;
  }
  if (/^-nostdinc/) {
    $cxxArgs .= " " . $_;
  }
}


$dirtyOut = parseOldDepends($inFile, $outFile, $dirtyIn);

#print "dirtyOut= $dirtyOut \n";
#print "cxxArgs= $cxxArgs \n";

foreach (split(" ",$dirtyOut)) {
  if (m/\.cpp$/ || m/\.c$/) {
    $compileList .= " " . $_;
  }
}

#print "compileList= $compileList \n";

if ($compileList ne "") {
  $uname = `uname`;
  chomp $uname;

  $plat = $ENV{"PLATFORM"};
  ($cmplr,$junk) = split(/\./,$plat);

  $gout = `g++ -M $cxxArgs $compileList`;
  if ($? != 0) {
    $! = 5;
    die "dependency generation failed";
  }
#  print "gout = $gout \n";

  $filler = $inFile;
  $filler =~ s|(.*/)[^/ ]*\.d$|\1|;
  $filler = $inFile . " " . $filler;
  collapse($filler, $gout);
}
close(OUTFILE);

if (stat($outFile) ne "") {
  rename($outFile, $inFile) 
    || die "$0 unable to rename $outFile to $inFile";
}










#$target = shift(@ARGV);
#$source = shift(@ARGV);
#$tmpFile = $target . ".tmp";
#
#foreach (@ARGV) {
#  if (/^-D.*/) {
#    $args .= " " . $_;
#  }
#  if (/^-I.*/) {
#    $args .= " " . $_;
#  }
#}
#
##print "args = $args \n";
#
#$cmplr = "g++ -M";#
#
#$out = `$cmplr $args $source`;
#if ($? != 0) {
#  $! = 5;
#  die "dependency generation failed";
#}
#
#unlink $tmpFile;
#open(OUTFILE, ">$tmpFile")
#  || die "$0 unable to open output file: $tmpFile";
#
#foreach (split("\n", $out)) {
#  foreach (split(" ", $_)) {
#    s|^/.*||og;
#    s|^[a-zA-Z]:.*||og;
#    if (/\\/) {
#      print OUTFILE $_;
#    } else {
#      print OUTFILE $_ . " ";
#    }
#  }
#  print OUTFILE "\n";
#}
#close(OUTFILE);
#
#if (stat($tmpFile) ne "") {
#  rename($tmpFile, $target) || die "$0 unable to rename $tmpFile to $target";
#}
