/*****************************************************************************
 * Copyright 1999, Scott McMillan
 *****************************************************************************
 *     File: 
 *   Author: Scott McMillan
 *  Created: 23 May 1999
 *  Summary: defining decl_spec's for NT port
 *****************************************************************************/

#ifndef __GAIT_HPP
#define __GAIT_HPP

#if defined(WIN32)
// The next define will come from the makefile for archive objects.
#ifdef aquarobot_DLL_FILE
#define GAIT_DLL_API __declspec(dllexport)
#else
#define GAIT_DLL_API __declspec(dllimport)
#endif
#else
#define GAIT_DLL_API
#endif

#if defined(WIN32)
#include <windows.h>
#include <iostream>
#include <iomanip>
#else
#include <iostream.h>
#include <iomanip.h>
#endif

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

// Use the std namespace. To do this we must first guarantee that it exists.
#if defined(__sgi) || defined(__WIN32_) || defined(WIN32)
namespace std {}
using namespace std;
#endif

#endif
