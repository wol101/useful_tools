/*****************************************************************************
 * Copyright 1998, Scott McMillan
 *****************************************************************************
 *     File: dmPositionConstraint.cpp
 *   Author: Scott McMillan
 *  Created: August 1998
 *  Summary: 
 *****************************************************************************/

#include "dmPositionConstraint.hpp"
#include <dmMobileBaseLink.hpp>

//----------------------------------------------------------------------------
dmPositionConstraint::dmPositionConstraint(dmArticulation *system,
                                           unsigned int ref_index) :
      m_system(system),
      m_ref_index(ref_index),
      m_K_spring(0.0),
      m_B_damper(0.0)
{
   m_offset[0] = m_offset[1] = m_offset[2] = 0.0;
}

//----------------------------------------------------------------------------
dmPositionConstraint::~dmPositionConstraint()
{
}

//----------------------------------------------------------------------------
void dmPositionConstraint::setConstants(CartesianVector offset,
                                        float K_spring,
                                        float B_damper)
{
   m_offset[0] = offset[0];
   m_offset[1] = offset[1];
   m_offset[2] = offset[2];

   m_K_spring = K_spring;
   m_B_damper = B_damper;
}

//----------------------------------------------------------------------------
void dmPositionConstraint::computeForce(dmABForKinStruct *val,
                                        SpatialVector force)
{
   int i;

   // get ref member position info
   dmABForKinStruct ref_val;
   m_system->forwardKinematics(m_ref_index, &ref_val);

   // compute delta position in ICS b/w ref mem origin and link+offset
   CartesianVector delta;
   for (i=0; i<3; i++)
   {
      delta[i] = ref_val.p_ICS[i] - val->p_ICS[i];
      for (int j=0; j<3; j++)
         delta[i] -= val->R_ICS[i][j]*m_offset[j];
   }

   // compute delta velocity in ICS b/w ref mem origin and link offset
   CartesianVector veref, vlink, velink, deltav;

   crossproduct(&val->v[0], m_offset, vlink);
   vlink[0] += val->v[3];
   vlink[1] += val->v[4];
   vlink[2] += val->v[5];

   for (i = 0; i < 3; i++)
   {
      velink[i] = val->R_ICS[i][XC]*vlink[XC] +
                  val->R_ICS[i][YC]*vlink[YC] +
                  val->R_ICS[i][ZC]*vlink[ZC];
      veref[i] = ref_val.R_ICS[i][XC]*ref_val.v[3] +
                 ref_val.R_ICS[i][YC]*ref_val.v[4] +
                 ref_val.R_ICS[i][ZC]*ref_val.v[5];
      deltav[i] = velink[i] - veref[i];
   }

   // compute spring force at origin of reference member
   CartesianVector ftemp;
   SpatialVector linear_force = {0.0,0.0,0.0, 0.0,0.0,0.0};
   for (i=0; i<3; i++)
   {
      ftemp[i] = delta[i]*m_K_spring - deltav[i]*m_B_damper;
                                        // force on link from ref mem.
   }

   // transform it to the ref mem CS
   for (i=0; i<3; i++)
   {
      for (int j=0; j<3; j++)
         linear_force[i+3] += ref_val.R_ICS[j][i]*(-ftemp[j]);
   }

   dmLink *link = m_system->getLink(m_ref_index);
   dmMobileBaseLink *rb = dynamic_cast<dmMobileBaseLink*>(link);
   if (rb)
   {
      rb->setExternalForce(linear_force);
   }

   // compute force and moment on this link at the offset position.
   for (i=0; i<3; i++)
      for (int j=0; j<3; j++)
         force[i+3] = val->R_ICS[j][i]*ftemp[j];

   crossproduct(m_offset, &force[3], &force[0]);
}
