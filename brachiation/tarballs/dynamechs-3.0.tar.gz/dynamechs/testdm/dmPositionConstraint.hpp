/*****************************************************************************
 * Copyright 1998, Scott McMillan
 *****************************************************************************
 *     File: dmPositionConstraint.hpp
 *   Author: Scott McMillan
 *  Created: August 1998
 *  Summary: models a position constraint for this particular demo (ring)
 *****************************************************************************/

#ifndef _DM_POSITION_CONSTRAINT_HPP
#define _DM_POSITION_CONSTRAINT_HPP

#include <dm.h>
#include <dmForce.hpp>
#include <dmArticulation.hpp>

#if defined(WIN32)
// The next define will come from the makefile for archive objects.
#ifdef testdm_DLL_FILE
#define TESTDM_DLL_API __declspec(dllexport)
#else
#define TESTDM_DLL_API __declspec(dllimport)
#endif
#else
#define TESTDM_DLL_API
#endif

//============================================================================

class TESTDM_DLL_API dmPositionConstraint : public dmForce
{
public:
   dmPositionConstraint(dmArticulation *system, unsigned int ref_index);
   virtual ~dmPositionConstraint();

   // specific functions
   void setConstants(CartesianVector offset, float K_spring, float B_damper);

   // required functions
   void reset() {};
   void computeForce(dmABForKinStruct *val, SpatialVector force);

// rendering functions (for future expansion/visualization):
   virtual void draw() {};

private:
   dmArticulation *m_system;
   unsigned int    m_ref_index;

   CartesianVector m_offset;
   float m_K_spring, m_B_damper;
};

#endif
